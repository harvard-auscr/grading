"""Compile a grading output folder into one self-contained HTML page.

    python tools/compile_html.py output            -> output/report.html

Reads <folder>/ysa*.json (one per paper), summary.csv and calibration.md; no network, no external assets.
"""
from __future__ import annotations

import base64
import csv
import glob
import hashlib
import html
import json
import os
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from autograde.model import METRICS  # noqa: E402

E = html.escape


def load(folder: Path):
    papers = [json.load(open(f, encoding="utf-8")) for f in sorted(glob.glob(str(folder / "*.json"))) if os.path.basename(f) != "summary.json"]
    papers = [p for p in papers if "metrics" in p]
    rows = list(csv.DictReader(open(folder / "summary.csv", encoding="utf-8"))) if (folder / "summary.csv").exists() else []
    calib = (folder / "calibration.md").read_text(encoding="utf-8") if (folder / "calibration.md").exists() else ""
    return papers, rows, calib


def cls(score):
    if score is None:
        return "na"
    return "good" if score >= 9 else "mid" if score >= 6 else "bad"


def fmt(score):
    return "—" if score is None else f"{score:.1f}"


def bars(papers, key):
    counts = Counter()
    for p in papers:
        s = p["overall"]["score"] if key == "overall" else p["metrics"][key]["score"]
        if s is not None:
            counts[round(s)] += 1
    top = max(counts.values(), default=1)
    cells = "".join(f'<div class="bar {cls(n)}" title="{n}: {counts[n]}"><i style="height:{counts[n] * 100 // top}%"></i><b>{n}</b></div>' for n in range(1, 11))
    return f'<div class="dist"><span>{E(key)}</span><div class="bars">{cells}</div><small>{sum(counts.values())} scored</small></div>'


def finding_rows(items, scored=True):
    out = []
    for f in items:
        para = "doc" if f.get("para") is None else f"¶{f['para']}"
        w = f" <em>−{f['weight']:g}</em>" if scored and f.get("weight") else ""
        out.append(f'<li><code>{E(f["code"])}</code>{w} <span class="para">{para}</span> <q>{E(f["quote"])}</q> <span class="note">{E(f["note"])}</span></li>')
    return "".join(out) or "<li class=none>none</li>"


def paper_block(p):
    ov = p["overall"]
    cells = "".join(f'<td class="s {cls(p["metrics"][m]["score"])}">{fmt(p["metrics"][m]["score"])}</td>' for m in METRICS)
    codes = Counter(f["code"] for m in p["metrics"].values() for f in m["findings"])
    detail = "".join(
        f'<section><h4>{E(m)} <span class="s {cls(p["metrics"][m]["score"])}">{fmt(p["metrics"][m]["score"])}</span> '
        f'<small>{E(p["metrics"][m]["status"])} · {E(p["metrics"][m]["rationale"])}</small></h4>'
        f'<ul>{finding_rows(p["metrics"][m]["findings"])}</ul>'
        + (f'<ul class="look">{finding_rows(p["metrics"][m]["look"], scored=False)}</ul>' if p["metrics"][m]["look"] else "")
        + "</section>" for m in METRICS)
    comments = "".join(f'<li><span class="para">{"doc" if c["para"] is None else "¶" + str(c["para"])}</span> <q>{E(c["quote"])}</q> — {E(c["note"])}</li>' for c in p.get("comments", []))
    red = ", ".join(f"{k} {v}" for k, v in sorted(p.get("redaction", {}).get("kinds", {}).items())) or "nothing masked"
    run = p.get("run", {})
    return (
        f'<tr class="row" data-id="{E(p["paper_id"])}" data-codes="{E(" ".join(sorted(codes)))}" data-overall="{ov["score"] if ov["score"] is not None else -1}">'
        f'<td class="id">{E(p["paper_id"])}</td><td>{E(str(p.get("round", "")))}</td><td class="n">{p.get("words", "")}</td>{cells}'
        f'<td class="s {cls(ov["score"])}"><b>{fmt(ov["score"])}</b>{"<sup>partial</sup>" if ov.get("partial") else ""}</td>'
        f'<td class="codes">{E(", ".join(f"{c} ×{n}" if n > 1 else c for c, n in codes.most_common(3)))}</td></tr>'
        f'<tr class="detail"><td colspan="{4 + len(METRICS)}"><div class="grid">{detail}</div>'
        f'<h4>Comments ({len(p.get("comments", []))})</h4><ul class="comments">{comments or "<li class=none>none</li>"}</ul>'
        f'<p class="meta">redaction: {E(red)} · model {E(str(run.get("model", "")))} · tiers {E(", ".join(run.get("tiers_run", [])))} · {run.get("seconds", "")} s</p></td></tr>'
    )


# The report's one script: static (no paper text), so its hash can be the only script the served report may run
# (web/server.py REPORT_CSP). Anything injected into the report would not match it.
SCRIPT = "\nconst tb=document.querySelector('#t tbody'),q=document.getElementById('q');\ntb.addEventListener('click',e=>{const r=e.target.closest('tr.row');if(!r)return;r.classList.toggle('open');r.nextElementSibling.classList.toggle('open')});\nq.addEventListener('input',()=>{const s=q.value.trim().toLowerCase();for(const r of tb.querySelectorAll('tr.row')){const hit=!s||r.dataset.id.includes(s)||r.dataset.codes.includes(s);r.classList.toggle('hidden',!hit);r.nextElementSibling.classList.toggle('hidden',!hit)}});\nlet dir=-1;document.querySelectorAll('#t th[data-k]').forEach(th=>th.addEventListener('click',()=>{const k=+th.dataset.k;dir=th.classList.contains('on')?-dir:-1;\ndocument.querySelectorAll('#t th').forEach(x=>x.classList.remove('on'));th.classList.add('on');\nconst pairs=[...tb.querySelectorAll('tr.row')].map(r=>[r,r.nextElementSibling]);\nconst val=r=>{const t=r.children[k].textContent.replace('partial','').trim();const n=parseFloat(t);return isNaN(n)?(t==='—'?-1:t):n};\npairs.sort((a,b)=>{const x=val(a[0]),y=val(b[0]);return (x<y?-1:x>y?1:0)*dir});pairs.forEach(p=>tb.append(...p))}));\n"
SCRIPT_SHA256 = base64.b64encode(hashlib.sha256(SCRIPT.encode("utf-8")).digest()).decode("ascii")


def build(folder: Path) -> str:
    papers, rows, calib = load(folder)
    failed = [r for r in rows if r.get("status") not in ("ok", "")]
    codes = Counter(f["code"] for p in papers for m in p["metrics"].values() for f in m["findings"])
    code_papers = Counter(c for p in papers for c in {f["code"] for m in p["metrics"].values() for f in m["findings"]})
    heads = "".join(f'<th data-k="{i}">{E(m)}</th>' for i, m in enumerate(METRICS, start=3))
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Grading report · {E(folder.name)}</title>
<style>
:root{{--ink:#1d1d1f;--mute:#6e6e73;--line:#e5e5ea;--good:#1f7a3a;--mid:#9a6700;--bad:#b3261e;--bg:#fafafa;--card:#fff}}
*{{box-sizing:border-box}}body{{margin:0;padding:24px 16px;font:14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:var(--ink);background:var(--bg)}}
h1{{font-size:22px;margin:0 0 4px}}h2{{font-size:16px;margin:28px 0 10px}}h4{{margin:6px 0 4px;font-size:13px;display:flex;gap:8px;align-items:baseline}}h4 small{{color:var(--mute);font-weight:400}}
.top{{display:flex;flex-wrap:wrap;gap:24px;align-items:flex-end}}.kpi{{color:var(--mute)}}.kpi b{{color:var(--ink);font-size:20px;display:block}}
.dists{{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px;margin:12px 0}}
.dist{{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:8px 10px}}.dist>span{{font-weight:600}}.dist small{{color:var(--mute)}}
.bars{{display:flex;gap:2px;height:48px;align-items:flex-end;margin:6px 0 2px}}.bar{{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;font-size:9px;color:var(--mute)}}
.bar i{{display:block;width:100%;min-height:1px;border-radius:2px 2px 0 0;background:#c7c7cc}}.bar.good i{{background:#8fd19e}}.bar.mid i{{background:#f2cf74}}.bar.bad i{{background:#f1a59f}}
input{{font:inherit;padding:6px 10px;border:1px solid var(--line);border-radius:6px;width:min(420px,100%)}}
table{{border-collapse:collapse;width:100%;background:var(--card);border:1px solid var(--line);border-radius:8px}}th,td{{padding:6px 8px;text-align:left;border-top:1px solid var(--line);vertical-align:top}}
th{{cursor:pointer;user-select:none;background:#f2f2f7;font-size:12px;color:var(--mute);position:sticky;top:0}}th.on::after{{content:" ▾"}}
.row{{cursor:pointer}}.row:hover{{background:#f5f5ff}}.row.open{{background:#eef2ff}}.detail{{display:none}}.detail.open{{display:table-row}}.detail td{{background:#fbfbfd}}
.id{{font-family:ui-monospace,Menlo,monospace;white-space:nowrap}}.n,.s{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}
.s.good{{color:var(--good)}}.s.mid{{color:var(--mid)}}.s.bad{{color:var(--bad);font-weight:600}}.s.na{{color:var(--mute)}}sup{{font-size:9px;color:var(--mute);margin-left:3px}}
.codes{{color:var(--mute);font-size:12px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px 24px}}
ul{{margin:0 0 6px;padding-left:18px}}li{{margin:2px 0}}li.none{{color:var(--mute);list-style:none;margin-left:-18px}}.look li{{color:var(--mute)}}
code{{background:#f2f2f7;padding:0 4px;border-radius:4px;font-size:12px}}em{{color:var(--bad);font-style:normal;font-size:12px}}.para{{color:var(--mute);font-size:12px}}q{{quotes:"“" "”";color:#3a3a3c}}.note{{color:var(--mute)}}
.comments q{{color:var(--ink)}}.meta{{color:var(--mute);font-size:12px;margin:8px 0 0}}pre{{white-space:pre-wrap;background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;font-size:12px}}
.freq td:last-child{{color:var(--mute)}}.hidden{{display:none}}
</style></head><body>
<h1>Grading report · {E(folder.name)}</h1>
<div class="top"><div class="kpi">papers<b>{len(papers)}</b></div><div class="kpi">failed / unparsed<b>{len(failed)}</b></div>
<div class="kpi">papers with deductions<b>{sum(1 for p in papers if any(m["findings"] for m in p["metrics"].values()))}</b></div>
<div class="kpi">findings<b>{sum(codes.values())}</b></div></div>
<h2>Score distributions</h2><div class="dists">{"".join(bars(papers, k) for k in ("overall", *METRICS))}</div>
<h2>Papers <small class="kpi">click a header to sort, a row to open; type to filter by id or finding code</small></h2>
<p><input id="q" placeholder="filter: ysa11-r2, citations.dangling, …" autofocus></p>
<table id="t"><thead><tr><th data-k="0">paper</th><th data-k="1">round</th><th data-k="2">words</th>{heads}<th data-k="{3 + len(METRICS)}" class="on">overall</th><th>top codes</th></tr></thead>
<tbody>{"".join(paper_block(p) for p in sorted(papers, key=lambda p: (p["overall"]["score"] is None, p["overall"]["score"] or 0)))}</tbody></table>
<h2>Findings by code</h2><table class="freq"><thead><tr><th>code</th><th>findings</th><th>papers</th></tr></thead><tbody>
{"".join(f"<tr><td><code>{E(c)}</code></td><td>{n}</td><td>{code_papers[c]}</td></tr>" for c, n in codes.most_common())}</tbody></table>
{f"<h2>Calibration</h2><pre>{E(calib)}</pre>" if calib else ""}
{f"<h2>Failed / unparsed</h2><pre>{E(chr(10).join(r['paper_id'] + ' ' + r['status'] for r in failed))}</pre>" if failed else ""}
<script>{SCRIPT}</script></body></html>"""


def main() -> int:
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else "output")
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else folder / "report.html"
    out.write_text(build(folder), encoding="utf-8")
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
