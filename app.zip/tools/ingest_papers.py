"""Ingest papers into data/papers/ under anonymous IDs, for any program/edition/round.

    python tools/ingest_papers.py --program ysa --edition 11 --round 2 \
        --sheet "data/<mastersheet>.csv" drive
    python tools/ingest_papers.py --program ysa --edition 11 --round 1 \
        --sheet "data/<mastersheet>.csv" zip data/r1---full.zip --include-unlisted
    python tools/ingest_papers.py --program ysa --edition 11 --round 1 \
        --sheet "data/<mastersheet>.csv" folder data/r1-papers/ --include-unlisted
    python tools/ingest_papers.py --program ysa --edition 11 exemplar data/a.docx data/b.docx

Sources
  drive     each sheet row carries a Google Docs/Drive link -> fetched by file ID
            (native Google Docs are exported to .docx). Sign-in is reused from the
            shoutouts repo (`shoutout_gen/drive.py`, full drive scope).
  zip       each sheet row carries a filename -> matched (case/punctuation-insensitive,
            extension-insensitive) against the zip members; .docx preferred over .pdf
            when both exist. --include-unlisted also ingests members no row references.
  folder    same matcher over the top-level files of a directory (non-recursive).
  exemplar  files given on the command line (grading-guide samples).
The sheet is optional for zip/folder: with none, every member is unlisted.

Naming
  <program><edition>-r<round>-<NN>   sheet rows, NN = 1-based sheet order
  <program><edition>-r<round>-u<NN>  unlisted zip/folder members
  <program><edition>-ex-<NN>         exemplars
The in-browser grader asks for no edition or round, so its IDs leave both out: <program>-<NN>, <program>-u<NN>.
The original extension is kept (.docx/.pdf/.wps); the grader decides what it can parse.

Manifest (data/papers/manifest.csv) carries no names: paper_id, program, edition,
round, role, sheet_row, source_kind, source_ref (drive file ID or content sha256),
ext, bytes. data/ is git-ignored; nothing here is ever committed. Idempotent.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import os
import re
import sys
import unicodedata
import zipfile
import zlib
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
from typing import Callable

HERE = Path(__file__).resolve().parent.parent
DATA = HERE / "data"
PAPERS = DATA / "papers"
MANIFEST = PAPERS / "manifest.csv"
FIELDS = ["paper_id", "program", "edition", "round", "role", "sheet_row", "source_kind", "source_ref", "ext", "bytes"]
SHOUTOUTS = HERE.parent / "hauscr-shoutouts"
DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
GDOC = "application/vnd.google-apps.document"
LINK_ID = re.compile(r"/d/([A-Za-z0-9_-]{20,})")
PREFER = {".docx": 0, ".doc": 1, ".pdf": 2, ".wps": 3}


# ---------------------------------------------------------------- sheet ----
class SheetError(ValueError):
    """The sheet cannot drive a round; the message is a plain sentence for the person who pasted it."""


class Refused(ValueError):
    """A linked file the grader will not download; the message is safe to log (no names)."""


MAX_PAPER_BYTES = 30 * 1024 * 1024
PAPER_TYPES = {GDOC: ".docx", DOCX: ".docx", "application/pdf": ".pdf"}


def read_sheet(path: Path):
    # csv over the whole text, not over splitlines(): a line break inside a quoted cell stays in the cell, and an
    # unquoted U+2028 in a title cannot split a row (which would shift every later sheet_row).
    rows = list(csv.reader(io.StringIO(path.read_text(encoding="utf-8-sig"), newline="")))
    hi = next(i for i, r in enumerate(rows) if any("Paper Title" in c for c in r))
    header = rows[hi]
    if len(header) == 1 and (";" in header[0] or "\t" in header[0]):   # every row would be one cell and match nothing
        raise SheetError("The mastersheet is not comma-separated. In Google Sheets: File, Download, "
                         "Comma-separated values.")
    body = [(i + 1, r) for i, r in enumerate(rows) if i > hi and len(r) > 5 and any(c.strip() for c in r)]
    return header, body


def find_col(header, *needles, required=True):
    for needle in needles:
        for j, c in enumerate(header):
            if needle.lower() in c.lower():
                return j
    if required:
        raise SystemExit(f"sheet has no column matching {needles}")
    return None


def norm(s: str) -> str:
    """A file or sheet name as matched: lower case, accents off, letters of every script and digits only, so
    "José_Final" and "jose final" agree and 李四海 and 王小明 stay apart."""
    s = unicodedata.normalize("NFKD", os.path.splitext(s)[0].casefold())
    return re.sub(r"[\W_]", "", "".join(c for c in s if not unicodedata.combining(c)))


# ------------------------------------------------------------- manifest ----
def load_manifest() -> dict[str, dict]:
    if not MANIFEST.exists():
        return {}
    with MANIFEST.open(encoding="utf-8") as fh:
        return {r["paper_id"]: r for r in csv.DictReader(fh)}


def save_manifest(rows: dict[str, dict]) -> None:
    PAPERS.mkdir(parents=True, exist_ok=True)
    with MANIFEST.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        for k in sorted(rows):
            w.writerow({f: rows[k].get(f, "") for f in FIELDS})


def store(manifest: dict, paper_id: str, data: bytes, ext: str, **meta) -> bool:
    dest = PAPERS / f"{paper_id}{ext}"
    if dest.exists() and dest.stat().st_size == len(data):
        manifest.setdefault(paper_id, {"paper_id": paper_id, **meta, "ext": ext, "bytes": len(data)})
        return False
    dest.write_bytes(data)
    manifest[paper_id] = {"paper_id": paper_id, **meta, "ext": ext, "bytes": len(data)}
    return True


# ---------------------------------------------------------------- drive ----
def drive_service(credentials=None):
    """Drive v3 client. With credentials (the hosted job's service account) it is built on them; without, it reuses
    the club's signed-in flow from the shoutouts repo."""
    from googleapiclient.discovery import build

    if credentials is None:
        sys.path.insert(0, str(SHOUTOUTS))
        from shoutout_gen import drive  # reuse the club's signed-in flow

        cfg = drive.load_config(SHOUTOUTS / ".env")
        sign_in = getattr(drive, "sign_in", None) or drive._sign_in   # renamed sign_in in shoutouts; accept either
        credentials = sign_in(cfg)
    return build("drive", "v3", credentials=credentials, cache_discovery=False)


def drive_fetch(svc, file_id: str) -> tuple[bytes, str]:
    """A paper's bytes and extension. Only Google Docs, .docx and .pdf are fetched, and nothing over MAX_PAPER_BYTES:
    the size is checked before the download (Google Docs exports are capped by Google at 10 MB)."""
    meta = svc.files().get(fileId=file_id, fields="mimeType,size", supportsAllDrives=True).execute()
    mime = meta.get("mimeType", "")
    if mime not in PAPER_TYPES:
        raise Refused("not a paper file type")
    if mime != GDOC and int(meta.get("size") or 0) > MAX_PAPER_BYTES:
        raise Refused(f"over {MAX_PAPER_BYTES // 2**20} MB")
    req = svc.files().export_media(fileId=file_id, mimeType=DOCX) if mime == GDOC else svc.files().get_media(fileId=file_id, supportsAllDrives=True)
    return req.execute(), PAPER_TYPES[mime]


def _why(exc: Exception) -> str:
    """A fetch failure for the log: our own refusal's reason, else the type and HTTP status, never Drive's text."""
    if isinstance(exc, Refused):
        return str(exc)
    status = getattr(getattr(exc, "resp", None), "status", "")
    return f"{type(exc).__name__} {status}".strip()


def drive_sheet_csv(svc, file_id: str) -> bytes:
    """A Google Sheet's first tab as CSV, the form --sheet reads."""
    return svc.files().export_media(fileId=file_id, mimeType="text/csv").execute()


def _drive_rows(sheet: Path, rnd, manifest, prefix, meta, svc) -> dict:
    """Fetch each sheet row's linked paper. Counts as ingest() returns them: a row with no link is unmatched, a link
    that could not be fetched is unreadable."""
    header, rows = read_sheet(Path(sheet))
    link_col = find_col(header, "docs.google", "drive.google", "Folder", "Link", required=False)
    if link_col is None:
        raise SheetError("That sheet has no column of paper links (a header with \"Link\" or \"Folder\" in it).")
    stored = present = unmatched = unreadable = 0
    for n, (sheet_row, r) in enumerate(rows, start=1):
        pid = f"{prefix}-r{rnd}-{n:02d}"
        m = LINK_ID.search(r[link_col]) if link_col < len(r) else None
        if not m:
            print(f"{pid}: no link in row {sheet_row}")
            unmatched += 1
            continue
        try:
            data, ext = drive_fetch(svc, m.group(1))
        except Exception as exc:  # noqa: BLE001
            print(f"{pid}: FAILED {_why(exc)}")
            unreadable += 1
            continue
        new = store(manifest, pid, data, ext, **meta, role="graded", sheet_row=sheet_row, source_kind="drive", source_ref=m.group(1))
        stored += new
        present += not new
    return {"stored": stored, "present": present, "unmatched_rows": unmatched, "unlisted": 0, "unreadable": unreadable}


def cmd_drive(a, manifest, prefix, meta):
    c = _drive_rows(Path(a.sheet), a.round, manifest, prefix, meta, drive_service())
    return c["stored"], c["present"], c["unmatched_rows"] + c["unreadable"]


def ingest_drive(program, edition, round, sheet: Path, papers: Path, svc) -> dict:
    """Fetch every sheet row's linked paper from Drive into papers/, returning ingest()'s counts (the hosted job)."""
    global PAPERS, MANIFEST
    PAPERS = Path(papers)
    MANIFEST = PAPERS / "manifest.csv"
    PAPERS.mkdir(parents=True, exist_ok=True)
    meta = {"program": program, "edition": edition, "round": round or ""}
    manifest = load_manifest()
    counts = _drive_rows(Path(sheet), round, manifest, f"{program}{edition}", meta, svc)
    save_manifest(manifest)
    return counts


# ------------------------------------------------------- zip / folder ----
Member = tuple[str, Callable[[], bytes]]


def _best(cands: list[Member]) -> Member:
    return min(cands, key=lambda m: PREFER.get(os.path.splitext(m[0])[1].lower(), 9))


def _ingest_members(members: list[Member], a, manifest, prefix, meta, tag: str | None = None) -> dict:
    """Shared matcher for zip/folder: sheet rows -> -rN-NN, extras -> -rN-uNN (<tag> in place of -rN when given).

    a carries .cmd (source_kind), .round, .sheet (optional), .include_unlisted.
    Filenames never appear in output; only paper_ids, sheet rows, and counts.
    """
    by_key: dict[str, list[Member]] = {}
    for basename, read in members:
        by_key.setdefault(norm(basename), []).append((basename, read))
    used: set[str] = set()
    stored = present = unmatched = unlisted = unreadable = 0
    tag = f"-r{a.round}" if tag is None else tag

    rows: list = []
    name_col = 0
    if a.sheet:
        try:
            header, rows = read_sheet(Path(a.sheet))
        except OSError:
            raise ValueError("mastersheet could not be read") from None
        name_col = _name_col(header, rows)
    for n, (sheet_row, r) in enumerate(rows, start=1):
        pid = f"{prefix}{tag}-{n:02d}"
        key = norm(r[name_col].strip()) if name_col < len(r) else ""
        cands = ((by_key.get(key) if key else None)   # an empty name matches nothing, not every unnamed file
                 or [m for k, v in by_key.items() if key and k and (key in k or k in key) for m in v])
        if not cands:
            print(f"{pid}: no file for sheet row {sheet_row}")
            unmatched += 1
            continue
        basename, read = _best(cands)
        used.add(norm(basename))
        try:
            data = read()
        except OSError:
            print(f"{pid}: a matched file could not be read")   # never the path (a student name)
            unreadable += 1
            continue
        new = store(manifest, pid, data, os.path.splitext(basename)[1].lower(), **meta,
                    role="graded", sheet_row=sheet_row, source_kind=a.cmd, source_ref=hashlib.sha256(data).hexdigest()[:16])
        stored += new
        present += not new
    if a.include_unlisted:
        for key in sorted(k for k in by_key if k not in used):
            pid = f"{prefix}{tag}-u{unlisted + 1:02d}"
            basename, read = _best(by_key[key])
            try:
                data = read()
            except OSError:
                print(f"{pid}: an unlisted file could not be read")
                unreadable += 1
                continue
            unlisted += 1
            new = store(manifest, pid, data, os.path.splitext(basename)[1].lower(), **meta,
                        role="unlisted", sheet_row="", source_kind=a.cmd, source_ref=hashlib.sha256(data).hexdigest()[:16])
            stored += new
            present += not new
    return {"stored": stored, "present": present, "unmatched_rows": unmatched,
            "unlisted": unlisted, "unreadable": unreadable}


def _name_col(header, rows) -> int:
    """The column a row's file is named in: "Paper Folder", else "File Name". A column that holds mostly links names
    nothing a zip or folder contains, so it is passed over for the next one."""
    for needle in ("Paper Folder", "File Name"):
        j = find_col(header, needle, required=False)
        if j is None:
            continue
        cells = [r[j].strip() for _, r in rows if j < len(r) and r[j].strip()]
        if cells and 2 * sum("://" in c or c.lower().startswith("www.") for c in cells) > len(cells):
            continue
        return j
    return find_col(header, "Paper Folder", "File Name")   # none usable: the usual message


def _member(z: zipfile.ZipFile, info: zipfile.ZipInfo, cap: int | None = None) -> bytes:
    """A zip member's bytes. Damaged, encrypted, packed with a method zipfile lacks, or over <cap> bytes (by the header
    or by what it inflates to): OSError, which the ingest counts as unreadable instead of stopping the round."""
    if cap is not None and info.file_size > cap:
        raise OSError("over the size cap")
    try:
        with z.open(info) as fh:
            data = fh.read() if cap is None else fh.read(cap + 1)
    except (zipfile.BadZipFile, NotImplementedError, EOFError, RuntimeError, zlib.error) as e:
        raise OSError(type(e).__name__) from None
    if cap is not None and len(data) > cap:   # the header understated the size
        raise OSError("over the size cap")
    return data


def _file(p: Path, cap: int | None = None) -> bytes:
    """A loose paper's bytes; over <cap> is OSError (unreadable), as for a zip member."""
    if cap is not None and p.stat().st_size > cap:
        raise OSError("over the size cap")
    return p.read_bytes()


def _basename(name: str) -> str:
    """A zip member's file name on every system: Windows zips may separate folders with backslashes."""
    return name.replace("\\", "/").rsplit("/", 1)[-1]


def _zip_members(path, cap: int | None = None) -> list[Member]:
    z = zipfile.ZipFile(path)
    return [(_basename(i.filename), (lambda i=i: _member(z, i, cap))) for i in z.infolist()
            if not i.is_dir() and _basename(i.filename)]   # "folder\" from a Windows zip is a folder, not a paper


def _loose(paths, cap: int | None = None) -> list[Member]:
    """Loose papers in the same order on every system (Windows sorts names without case, Linux with)."""
    files = sorted((p for p in paths if p.is_file() and p.suffix.lower() in PREFER),
                   key=lambda p: (p.name.casefold(), p.name))
    return [(p.name, (lambda p=p: _file(p, cap))) for p in files]


def cmd_zip(a, manifest, prefix, meta) -> dict:
    return _ingest_members(_zip_members(a.zipfile), a, manifest, prefix, meta)


def cmd_folder(a, manifest, prefix, meta) -> dict:
    return _ingest_members(_loose(Path(a.folder).iterdir()), a, manifest, prefix, meta)


def _run(program, edition, round, kind: str, members_of, sheet, papers, include_unlisted, round_in_ids=True) -> dict:
    global PAPERS, MANIFEST
    PAPERS = Path(papers)
    MANIFEST = PAPERS / "manifest.csv"
    PAPERS.mkdir(parents=True, exist_ok=True)
    a = SimpleNamespace(cmd=kind, round=round, sheet=str(sheet) if sheet else None, include_unlisted=include_unlisted)
    meta = {"program": program, "edition": edition, "round": round or ""}
    manifest = load_manifest()
    counts = _ingest_members(members_of(), a, manifest, f"{program}{edition}", meta, None if round_in_ids else "")
    save_manifest(manifest)
    return counts


def ingest(program, edition, round, source: Path, sheet: Path | None, papers: Path, include_unlisted=True,
           round_in_ids=True) -> dict:
    """Ingest a .zip file or a directory of papers, returning the count dict.

    Sets the module PAPERS/MANIFEST for this call (the launcher's --papers override).
    """
    src = Path(source)
    if src.is_file():
        return _run(program, edition, round, "zip", lambda: _zip_members(src), sheet, papers, include_unlisted,
                    round_in_ids)
    return _run(program, edition, round, "folder", lambda: _loose(src.iterdir()), sheet, papers, include_unlisted,
                round_in_ids)


def ingest_sources(program, edition, round, sources: list[Path], sheet: Path | None, papers: Path,
                   include_unlisted=True, round_in_ids=True) -> dict:
    """ingest() over several zips and loose papers at once, for the in-browser grader (Drive splits a big folder into
    several zips). One member list, so one zip gives exactly what ingest() gives; every paper over MAX_PAPER_BYTES
    counts as unreadable however it arrived (a browser tab has little memory). The counts add "same_name": files
    left out because another file has the same name (only one of each name is graded). round_in_ids=False numbers
    the papers <program><edition>-NN, without the round."""
    found: list[Member] = []
    for z in sorted((Path(p) for p in sources if Path(p).suffix.lower() == ".zip"), key=lambda p: (p.name.casefold(), p.name)):
        found += _zip_members(z, MAX_PAPER_BYTES)
    found += _loose([Path(p) for p in sources], MAX_PAPER_BYTES)
    counts = _run(program, edition, round, "zip", lambda: found, sheet, papers, include_unlisted, round_in_ids)
    names = Counter(norm(b) for b, _ in found)
    counts["same_name"] = sum(n - 1 for n in names.values())
    return counts


# ------------------------------------------------------------- exemplar ----
def cmd_exemplar(a, manifest, prefix, meta):
    n_new = n_skip = 0
    existing = sorted(k for k in manifest if k.startswith(f"{prefix}-ex-"))
    for n, f in enumerate(a.files, start=len(existing) + 1):
        p = Path(f)
        data = p.read_bytes()
        pid = f"{prefix}-ex-{n:02d}"
        new = store(manifest, pid, data, p.suffix.lower(), **meta, role="exemplar", sheet_row="", source_kind="local", source_ref=hashlib.sha256(data).hexdigest()[:16])
        n_new += new
        n_skip += not new
    return n_new, n_skip, 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--program", required=True, help="e.g. ysa, ctb")
    ap.add_argument("--edition", required=True, help="e.g. 11")
    ap.add_argument("--round", type=int, default=0, help="review round (drive/zip/folder)")
    ap.add_argument("--sheet", help="mastersheet CSV export (optional for zip/folder)")
    ap.add_argument("--papers", help="output dir (default data/papers)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("drive")
    pz = sub.add_parser("zip")
    pz.add_argument("zipfile")
    pz.add_argument("--include-unlisted", action="store_true")
    pf = sub.add_parser("folder")
    pf.add_argument("folder")
    pf.add_argument("--include-unlisted", action="store_true")
    pe = sub.add_parser("exemplar")
    pe.add_argument("files", nargs="+")
    a = ap.parse_args()
    if a.cmd == "drive" and not (a.sheet and a.round):
        ap.error("--sheet and --round are required for drive")

    global PAPERS, MANIFEST
    if a.papers:
        PAPERS = Path(a.papers)
        MANIFEST = PAPERS / "manifest.csv"

    if a.cmd in ("zip", "folder"):
        source = a.zipfile if a.cmd == "zip" else a.folder
        counts = ingest(a.program, a.edition, a.round, Path(source),
                        Path(a.sheet) if a.sheet else None, PAPERS, include_unlisted=a.include_unlisted)
        print(counts)
        return 1 if counts["unmatched_rows"] else 0

    prefix = f"{a.program}{a.edition}"
    meta = {"program": a.program, "edition": a.edition, "round": a.round or ""}
    manifest = load_manifest()
    try:
        n_new, n_skip, n_fail = {"drive": cmd_drive, "exemplar": cmd_exemplar}[a.cmd](a, manifest, prefix, meta)
    except SheetError as e:
        print(e)
        return 2
    save_manifest(manifest)
    print(f"done: {n_new} stored, {n_skip} already present, {n_fail} failed -> {PAPERS}")
    return 1 if n_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
