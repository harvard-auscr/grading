"""HAUSCR auto-grader CLI. Mechanical checks for research papers; program/edition/round are parameters.

    python grade.py --program ysa --papers data/papers --out output \
        --sheet 1="data/...1st Round.csv" --sheet 2="data/...2nd Round.csv" [--calibrate]

Sibling modules are imported lazily so `--help` works before the package is complete.
"""
from __future__ import annotations

import argparse
import functools
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ON_PAPER = None   # the in-browser build sets this: called (paper_id, status, done, total) after each paper
AI_NEEDS_NAMES = False   # the in-browser build sets this: a paper whose sheet row names no student gets no AI checks


def load_env(root: Path) -> None:
    """Copy KEY=VALUE lines from .env into os.environ for keys not already set."""
    env = root / ".env"
    if not env.exists():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def parse_sheets(pairs: list[str] | None) -> dict[int, str]:
    out: dict[int, str] = {}
    for p in pairs or []:
        if "=" not in p:
            raise SystemExit(f"--sheet expects <round>=<path>, got {p!r}")
        rnd, path = p.split("=", 1)
        out[int(rnd)] = path
    return out


def grade_one(row: dict, papers: Path, out: Path, rubric_dict: dict, sheets: dict,
              cache, ask, args) -> dict:
    from autograde import (citations, docx, figures, net, numbers, redact,
                           relevancy, report, resolve as resolve_mod, rubric, sections, sheet)
    from autograde.model import Metric

    pid = row["paper_id"]
    ext = row.get("ext", ".docx") or ".docx"
    path = papers / f"{pid}{ext}"
    meta = {"paper_id": pid, "program": row.get("program", ""), "edition": row.get("edition", ""),
            "round": row.get("round", ""), "source": f"{pid}{ext}"}
    t0, hits0 = time.monotonic(), cache.hits

    on = rubric_dict["metrics"]                            # the checks this program's rubric runs

    def off(name: str) -> Metric:
        return Metric(name, None, status="skipped", rationale="not in this rubric")

    doc = docx.read(path)                                  # raises Unparsed
    structure = sections.run(doc, rubric_dict) if "structure" in on else off("structure")
    cite_metric, refs, markers = citations.run(doc)        # the references feed the later checks too
    if "citations" not in on:
        cite_metric = off("citations")
    figs = figures.run(doc) if "figures" in on else off("figures")

    sheet_row = sheet.row_for(row, sheets)
    red = redact.build(doc, sheet_row, others=sheet.round_rows(row, sheets))
    if sheet_row is None:
        red.report["no_sheet_row"] = 1   # sheet-driven name/school masking did not run: make it visible

    if args.offline:
        res = Metric("resolvability", None, status="skipped", rationale="offline")
    elif not {"resolvability", "relevancy", "numbers"} & set(on):
        res = off("resolvability")
    else:   # relevancy and numbers read the abstracts and sources that resolving finds; its searches go out masked
        res = resolve_mod.run(refs, cache, offline=False, scrub=red.scrub)
        if "resolvability" not in on:
            res = off("resolvability")

    tiers = [t for t in ("structure", "citations", "figures") if t in on]
    if not args.offline and "resolvability" in on:
        tiers.append("resolvability")
    tally0 = None                                          # set when the AI checks run
    if not {"relevancy", "numbers"} & set(on):
        rel, nums = off("relevancy"), off("numbers")
    elif ask is None:
        rel = Metric("relevancy", None, status="skipped", rationale="no llm")
        nums = Metric("numbers", None, status="skipped", rationale="no llm")
    else:
        from autograde import llm
        tally0 = dict(llm.TALLY)

        def offline_fetch(url, **k):
            raise net.NetError("offline")
        rel = relevancy.run(red, refs, markers, ask) if "relevancy" in on else off("relevancy")
        nums = (numbers.run(red, refs, markers, ask, fetch=(offline_fetch if args.offline else net.get))
                if "numbers" in on else off("numbers"))
        tiers += [t for t in ("relevancy", "numbers") if t in on]

    metrics = {"structure": structure, "citations": cite_metric, "resolvability": res,
               "relevancy": rel, "numbers": nums, "figures": figs}
    for m in metrics.values():
        rubric.score(m, rubric_dict)
    overall = rubric.overall(metrics, rubric_dict)
    look, dropped = rubric.cap_look(metrics, rubric_dict)

    run = {"model": getattr(args, "llm_model", "none") if ask else "none", "tiers_run": sorted(tiers),
           "cache_hits": cache.hits - hits0, "look_dropped": dropped,
           "seconds": round(time.monotonic() - t0, 2)}
    if ask is not None:   # this paper's LLM traffic: who served it, calls, how many were metered, tokens
        run["provider"] = getattr(args, "llm_provider", "")
        if tally0 is not None:
            run.update({f"llm_{k}": llm.TALLY[k] - tally0[k] for k in llm.TALLY})
    data = report.write_paper(out, meta, doc, metrics, overall, look, red, run)
    data["role"], data["references"] = row.get("role", ""), len(refs)
    data["sheet_row"] = row.get("sheet_row", "")
    data["status"] = "ok"
    return data


def run(args) -> int:
    load_env(ROOT)
    from autograde import report, rubric, sheet
    from autograde.cache import Cache
    from autograde.model import Unparsed

    papers = Path(args.papers)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:   # the whole rubric is checked before any paper is read
        rubric_dict = rubric.load(Path(args.rubric) if args.rubric else rubric.path_for(args.program, ROOT / "rubric"))
    except rubric.RubricError as e:
        print(e, file=sys.stderr)
        return 2
    rubric.use(rubric_dict)
    manifest = sheet.manifest(papers / "manifest.csv")
    sheets = {rnd: sheet.load(p) for rnd, p in parse_sheets(args.sheet).items()}

    cache = Cache()
    ask = client = None
    args.llm_model = args.llm_provider = "none"
    if not args.no_llm:
        try:
            from autograde import llm
            tally0 = dict(llm.TALLY)
            if args.llm == "oracle":   # no API: verdicts come from the cache, misses are exported for agents to answer
                if args.llm_answers:
                    print(f"loaded {llm.load_answers(cache, args.llm_answers)} answers")
                llm.EXPORT = out / "llm-requests.jsonl"
                llm.EXPORT.unlink(missing_ok=True)
                client = llm.ORACLE
            else:
                client = llm.make_client()
            if client is not None:
                ask = functools.partial(llm.ask, client, cache)
                args.llm_provider = llm.provider_of(client)
                args.llm_model = "oracle" if client == llm.ORACLE else llm.model_of(client)
        except Exception:
            ask = None

    rows = [r for r in manifest if not args.paper or r["paper_id"] == args.paper]
    rows.sort(key=lambda r: r["paper_id"])
    if args.limit:
        rows = rows[: args.limit]

    log = (out / "run.log").open("a", encoding="utf-8")
    results: list[dict] = []
    bad = 0
    from autograde import redact
    for row in rows:
        pid = row["paper_id"]
        paper_ask = ask
        if ask is not None and AI_NEEDS_NAMES and not redact.names_known(sheet.row_for(row, sheets)):
            paper_ask = None   # nothing to mask its student's name by, so nothing of it goes to an AI
        try:
            data = grade_one(row, papers, out, rubric_dict, sheets, cache, paper_ask, args)
            detail = f"overall={data['overall'].get('score')}"
        except Unparsed as e:
            data = {"paper_id": pid, "round": row.get("round", ""), "sheet_row": row.get("sheet_row", ""),
                    "status": "unparsed", "error": str(e)}
            detail = f"unparsed: {e}"
            bad += 1
        except Exception as e:                            # a bad paper never aborts the batch
            data = {"paper_id": pid, "round": row.get("round", ""), "sheet_row": row.get("sheet_row", ""),
                    "status": "failed", "error": type(e).__name__}
            detail = f"failed: {type(e).__name__}: {str(e)[:120]}"
            bad += 1
        results.append(data)
        r = data.get("run", {})
        if "llm_calls" in r:   # fourth column: what this paper's LLM checks weighed, for pricing a round
            detail += f"\tllm_calls={r['llm_calls']} tokens_in={r['llm_tokens_in']} tokens_out={r['llm_tokens_out']}"
        log.write(f"{pid}\t{data['status']}\t{detail}\n")
        log.flush()   # the launcher tails run.log for live progress
        if ON_PAPER is not None:
            ON_PAPER(pid, data["status"], len(results), len(rows))
    log.close()

    if ask is not None:
        t = {k: llm.TALLY[k] - tally0[k] for k in llm.TALLY}
        n = sum(1 for r in results if r.get("status") == "ok") or 1
        print(f"llm: {args.llm_provider}/{args.llm_model}  calls={t['calls']} metered={t['metered']}  "
              f"tokens_in={t['tokens_in']} tokens_out={t['tokens_out']} (reasoning {t['tokens_reasoning']}, cached in {t['tokens_in_cached']})  "
              f"per_paper={t['tokens_in'] // n}+{t['tokens_out'] // n}"
              + (f"  last_status={client.status}" if getattr(client, "status", None) not in (None, 200) else ""), flush=True)
        report.write_usage(out, results)
        report.write_prompts(out, args.llm_provider, args.llm_model)

    report.write_summary(out, results)
    if args.calibrate:
        from autograde import calibrate
        calibrate.write(out, results, sheets)
    return 1 if bad else 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="grade.py", description="HAUSCR auto-grader (mechanical checks).")
    ap.add_argument("--program", default="ysa", help="picks rubric/<program>.toml")
    ap.add_argument("--rubric", metavar="TOML", help="grade with this rubric file instead (e.g. a draft for a new program)")
    ap.add_argument("--papers", default="data/papers")
    ap.add_argument("--out", default="output")
    ap.add_argument("--sheet", action="append", metavar="ROUND=PATH", help="repeatable, e.g. --sheet 1=path.csv")
    ap.add_argument("--paper", help="grade only this paper_id")
    ap.add_argument("--no-llm", action="store_true", help="deterministic metrics only")
    ap.add_argument("--llm", choices=("api", "oracle"), default="api", help="oracle = no API calls; export misses, answer from cache")
    ap.add_argument("--llm-answers", metavar="JSONL", help="oracle answers to load into the cache before grading")
    ap.add_argument("--offline", action="store_true", help="skip resolvability and source fetches")
    ap.add_argument("--calibrate", action="store_true", help="also write calibration.md")
    ap.add_argument("--limit", type=int, help="grade at most N papers")
    return ap


def main(argv=None) -> int:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())
