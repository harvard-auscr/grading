from __future__ import annotations

import hashlib
import io
import re

from . import net
from .model import Finding, Marker, Metric, Ref, UNWEIGHED
from .redact import Redactor

CAP = 12
UNVERIFIABLE_LIST = 3
SOURCE_TRUNC = 40_000
MIN_CHARS = 2_000
_NUM = re.compile(
    r"\d+(?:\.\d+)?\s*%|\d{1,3}(?:,\d{3})+|"
    r"\d+(?:\.\d+)?\s*(?:million|billion|thousand|万|亿)|[$¥€£]\s?\d",
    re.I,
)
_TAG = re.compile(r"<(script|style)\b.*?</\1>", re.I | re.S)
_STRIP = re.compile(r"<[^>]+>")
SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string", "enum": ["present", "absent", "cannot_tell"]},
        "why": {"type": "string"},
    },
    "required": ["verdict", "why"],
    "additionalProperties": False,
}
_TASK = (
    "Does the source text below contain the numeric fact stated in the sentence "
    "(same figure and referent, allowing rounding/format)?\n"
    "verdict: present | absent | cannot_tell. Keep 'why' to <= 12 words.\n"
)
TEMPLATE = _TASK + "\nSentence: {sentence}\n\nSource text:\n{source}"
EXAMPLE = {"verdict": "present", "why": "source states the same figure"}


def _strip_html(body: bytes) -> str:
    html = body.decode("utf-8", errors="replace")
    html = _TAG.sub(" ", html)
    text = _STRIP.sub(" ", html)
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
    return re.sub(r"\s+", " ", text).strip()


def _pdf_text(body: bytes) -> str | None:
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(body))
        return re.sub(r"\s+", " ", " ".join((pg.extract_text() or "") for pg in reader.pages)).strip()
    except Exception:
        return None


def _raw_text(url: str, fetch, memo: dict) -> str | None:
    """Fetched source text, or None when the source is unusable (status/type/size/parse)."""
    if url in memo:
        return memo[url]
    text: str | None = None
    try:
        status, ctype, body = fetch(url)
        ctype = (ctype or "").lower()
        if status == 200 and any(k in ctype for k in ("html", "pdf", "text")):
            raw = _pdf_text(body) if "pdf" in ctype else _strip_html(body)
            if raw is not None:
                raw = raw[:SOURCE_TRUNC]
                if len(raw) >= MIN_CHARS:
                    text = raw
    except Exception:   # NetError or any transport/decode failure -> unusable
        text = None
    memo[url] = text
    return text


def _title_match(title: str, text: str) -> bool:
    tset = set(re.findall(r"\w+", title.lower()))
    if not tset:
        return False
    words = re.findall(r"\w+", text.lower())
    if not words:
        return False
    windows = [words[s:s + 40] for s in range(0, max(1, len(words) - 39), 10)]
    windows.append(words[-40:])
    for win in windows:
        wset = set(win)
        inter = len(tset & wset)
        if inter and inter / len(tset | wset) >= 0.5:
            return True
    return False


def _source_url(ref: Ref | None) -> str | None:
    if ref is None:
        return None
    if ref.url and ref.url.lower().startswith(("http://", "https://")):
        return ref.url
    oa = (ref.found or {}).get("oa_url") if ref.found else None
    if oa and oa.lower().startswith(("http://", "https://")):
        return oa
    return None


def run(red: Redactor, refs: list[Ref], markers: list[Marker], ask, fetch=net.get) -> Metric:
    by_i = {r.i: r for r in refs}
    skip = getattr(red, "dropped", set())   # acknowledgments and front matter never reach the LLM
    candidates = [m for m in sorted(markers, key=lambda m: m.para)
                  if len(m.entries) == 1 and _NUM.search(m.text) and m.para not in skip]
    dropped = max(0, len(candidates) - CAP)
    candidates = candidates[:CAP]
    if not candidates:
        return Metric("numbers", None, status="not_applicable", rationale="no cited numeric claims")

    findings: list[Finding] = []
    unverifiable: list[Finding] = []
    memo: dict[str, str | None] = {}
    status = "ok"
    checked = 0
    for m in candidates:
        ref = by_i.get(m.entries[0])
        sentence = red.scrub(m.text)
        url = _source_url(ref)
        text = _raw_text(url, fetch, memo) if url else None
        ok = bool(text) and (_title_match(ref.title, text) or (ref.doi and ref.doi in text))
        if not ok:
            unverifiable.append(Finding("numbers.unverifiable", 0.0, m.para, sentence, "source unreachable or off-source"))
            continue
        prompt = TEMPLATE.format(sentence=sentence, source=text[:SOURCE_TRUNC])
        key = "numbers:" + hashlib.sha256((sentence + "\x1f" + url).encode("utf-8")).hexdigest()
        res = ask(SCHEMA, prompt, key)
        if res is None:
            status = "partial"
            continue
        checked += 1
        if res.get("verdict") == "absent":
            findings.append(Finding("numbers.absent_from_source", UNWEIGHED, m.para, sentence,
                                    (res.get("why") or "")[:120]))

    look = unverifiable[:UNVERIFIABLE_LIST]
    if len(unverifiable) > UNVERIFIABLE_LIST:
        look = look + [Finding("numbers.unverifiable", 0.0, None, "", f"+{len(unverifiable) - UNVERIFIABLE_LIST} more")]

    bits = []
    if findings:
        bits.append(f"{len(findings)} absent")
    if checked:
        bits.append(f"{checked} checked")
    if unverifiable:
        bits.append(f"{len(unverifiable)} unverifiable")
    if dropped:
        bits.append(f"{dropped} over cap")
    rationale = ", ".join(bits) or "no numeric claims verified"
    findings.sort(key=lambda f: (f.para if f.para is not None else -1, f.quote))
    return Metric("numbers", None, findings=findings, look=look, rationale=rationale, status=status)
