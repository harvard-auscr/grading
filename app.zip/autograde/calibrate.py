from __future__ import annotations

import re
from collections import Counter, defaultdict
from pathlib import Path

from autograde import sheet
from autograde.model import METRICS


def _num(v):
    try:
        return float(str(v).strip())
    except (TypeError, ValueError):
        return None


def _norm(t: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (t or "").lower())


def _avg_ranks(xs: list[float]) -> list[float]:
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    ranks = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        avg = (i + j) / 2 + 1                # average of tied 1-based ranks
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def _pearson(a: list[float], b: list[float]) -> float | None:
    n = len(a)
    if n < 2:
        return None
    ma, mb = sum(a) / n, sum(b) / n
    da = [x - ma for x in a]
    db = [x - mb for x in b]
    num = sum(x * y for x, y in zip(da, db))
    den = (sum(x * x for x in da) * sum(y * y for y in db)) ** 0.5
    return round(num / den, 3) if den else None


def _score(r: dict, name: str):
    m = (r.get("metrics") or {}).get(name)
    return None if not m else m.get("score")


def write(out: Path, results: list[dict], sheets: dict) -> Path:
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    graded = [r for r in results if r.get("status") == "ok"]
    L = ["# Calibration (internal)", "",
         f"papers graded: {len(graded)} / {len(results)}", ""]

    # per-metric score histogram 1..10
    L += ["## Score histograms (1-10)", ""]
    for name in METRICS:
        bins = Counter()
        for r in graded:
            s = _score(r, name)
            if s is not None:
                bins[min(10, max(1, round(s)))] += 1
        cells = " ".join(f"{b}:{bins.get(b, 0)}" for b in range(1, 11))
        L.append(f"- **{name}** {cells}")
    L.append("")

    # top 15 finding codes
    codes = Counter(f["code"] for r in graded for m in (r.get("metrics") or {}).values()
                    for f in m.get("findings", []))
    L += ["## Top finding codes", ""]
    for code, n in sorted(codes.items(), key=lambda kv: (-kv[1], kv[0]))[:15]:
        L.append(f"- {code}: {n}")
    if not codes:
        L.append("_none_")
    L.append("")

    # per-discipline mean overall
    by_disc: dict[str, list[float]] = defaultdict(list)
    for r in graded:
        row = sheet.row_for(r, sheets)
        o = (r.get("overall") or {}).get("score")
        if row and row.get("discipline") and o is not None:
            by_disc[row["discipline"]].append(o)
    L += ["## Mean overall by discipline", ""]
    for disc in sorted(by_disc):
        vals = by_disc[disc]
        L.append(f"- {disc}: {round(sum(vals) / len(vals), 2)} (n={len(vals)})")
    if not by_disc:
        L.append("_none_")
    L.append("")

    # Spearman: structure score vs sheet Writing Structure
    xs, ys = [], []
    for r in graded:
        row = sheet.row_for(r, sheets)
        s = _score(r, "structure")
        w = _num(row.get("writing_structure")) if row else None
        if s is not None and w is not None:
            xs.append(s)
            ys.append(w)
    rho = _pearson(_avg_ranks(xs), _avg_ranks(ys)) if len(xs) >= 2 else None
    L += ["## Structure vs Writing Structure (Spearman)", "",
          f"rho = {rho} (n={len(xs)})", ""]

    # round-1 vs round-2 pairs by normalized title
    by_title: dict[str, dict[str, dict]] = defaultdict(dict)
    for r in graded:
        row = sheet.row_for(r, sheets)
        rd = str(r.get("round", ""))
        if row and row.get("title") and rd in ("1", "2"):
            by_title[_norm(row["title"])][rd] = r
    deltas: dict[str, list[float]] = defaultdict(list)
    pairs = 0
    for key in sorted(by_title):
        pair = by_title[key]
        if "1" in pair and "2" in pair:
            pairs += 1
            for name in METRICS:
                a, b = _score(pair["1"], name), _score(pair["2"], name)
                if a is not None and b is not None:
                    deltas[name].append(b - a)
    L += ["## Round-1 -> round-2 mean delta per metric", "", f"pairs: {pairs}", ""]
    for name in METRICS:
        d = deltas.get(name, [])
        if d:
            L.append(f"- {name}: {round(sum(d) / len(d), 2)} (n={len(d)})")
    L.append("")

    path = out / "calibration.md"
    path.write_text("\n".join(L), encoding="utf-8")
    return path
