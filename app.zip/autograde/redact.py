from __future__ import annotations

import re
import unicodedata

from . import headings
from .model import Doc

MASK = "▮"   # ▮
FRONT_MATTER_CAP = 40
_EMAIL = re.compile(r"(?<![\w.+-])[\w.+-]+@[\w-]+(?:\.[\w-]+)+")   # tried only where a run starts: linear time
_SCHOOL_WORDS = re.compile(r"school|university|academy|college", re.I)
_AFFILIATION = re.compile(r"school|universit|academy|college|institute|department|dept\b|laborator|\blab\b|hospital|"
                          r"company|corporation|\binc\b|\bltd\b|大学|学院|中学|研究所|研究院|实验室|医院|公司", re.I)
_LETTER = r"[a-zß-öø-ɏ]"   # a Latin letter of the folded text
_NB, _NA = rf"(?<!{_LETTER})", rf"(?!{_LETTER})"   # letter edges: a digit, _, / or a Chinese character ends a name
_CJK = r"[㐀-鿿豈-﫿]"
_SEP = r"[\s,.\-_+]{1,3}"     # own name and mentor: "Wei Li", "Li, Wei", "Li-Wei", "Wei_Li", "Wei+Li"
_GAP = r"[\s_+]{1,3}"         # classmates: a real gap, since "Li, Na" and "Na-Li" are chemistry, not a classmate
_BREAK = r"[\s\-]?"           # inside a name part: the sheet's "Xiaoming" written "Xiao-Ming" or "Xiao Ming"
_TITLE = r"(?:prof(?:essor)?|dr|doctor|mr|mrs|ms|miss)(?:\.\s*|\s+)"     # "Dr. Zhang", "Dr.Zhang", "Prof Zhang"
_ROLE = r"(?:teacher|mentor|advisor|adviser|supervisor|instructor)(?:\s+|\.(?!\s))"   # "my mentor Zhang"
_HONORIFIC = rf"\s*(?:lao\s?shi{_NA}|老师|教授|导师|博士)"   # "Zhang laoshi", "Zhang老师"
_CN_HONORIFIC = r"\s*(?:老师|教授|导师|博士)"                # "张老师" for the mentor 张华
_CITED = r"(?!\s*(?:et\.?\s+al|\(\d{4}[a-z]?(?:[,;][^()]*)?\)))"   # "Dr. Wang et al.", "Professor Li (2019, p. 3)"
_HANDLE = "/@_+#."            # around a name in an address, a handle or a file name
_SKIP = {"Cf", "Mn", "Me"}    # invisible format characters and combining accents: left out of the text names are matched in
_NOT_NAMES = {"prof", "professor", "dr", "doctor", "mr", "mrs", "ms", "miss", "teacher", "mentor", "advisor",
              "adviser", "supervisor", "instructor", "of", "the", "and", "school", "university", "college",
              "academy", "institute", "department", "high", "middle", "international"}
_SCHOOL_GENERIC = {"school", "schools", "high", "middle", "junior", "senior", "primary", "secondary", "international",
                   "university", "college", "academy", "institute", "experimental", "foreign", "language", "languages",
                   "bilingual", "normal", "affiliated", "attached", "division", "campus", "district", "city", "county",
                   "province", "provincial", "municipal", "national", "state", "public", "private", "number", "china",
                   "chinese", "american", "british", "canadian", "united", "states", "kingdom", "new", "north", "south",
                   "east", "west", "central", "science", "technology", "arts", "education", "educational", "group",
                   "branch", "program", "programme", "centre", "center", "with", "from", "into"}
_PLACES = {"beijing", "shanghai", "tianjin", "chongqing", "guangzhou", "shenzhen", "hangzhou", "nanjing", "wuhan",
           "chengdu", "xian", "suzhou", "qingdao", "dalian", "xiamen", "ningbo", "shenyang", "harbin", "changsha",
           "zhengzhou", "jinan", "hefei", "fuzhou", "kunming", "nanning", "guiyang", "lanzhou", "taiyuan",
           "shijiazhuang", "hohhot", "urumqi", "lhasa", "xining", "yinchuan", "haikou", "nanchang", "changchun", "hong",
           "kong", "macau", "macao", "taipei", "guangdong", "jiangsu", "zhejiang", "shandong", "henan", "hebei", "hubei",
           "hunan", "sichuan", "fujian", "anhui", "jiangxi", "shaanxi", "shanxi", "liaoning", "jilin", "heilongjiang",
           "yunnan", "guizhou", "guangxi", "gansu", "qinghai", "hainan", "ningxia", "xinjiang", "tibet", "xizang",
           "inner", "mongolia", "taiwan", "singapore", "london", "boston", "toronto", "vancouver", "sydney",
           "melbourne", "california", "york"}
_PLACEHOLDERS = {"na", "n a", "none", "nil", "null", "tbd", "tba", "unknown", "no", "no mentor", "self", "无", "暂无",
                 "没有", "pending", "withdrawn", "anonymous", "student", "loading", "true", "false", "待定", "未知",
                 "不详", "同上", "退出"}
_FOLD = str.maketrans({"ø": "o", "ł": "l", "đ": "d", "ı": "i", "ħ": "h", "ŧ": "t", "ŀ": "l", "þ": "t", "ð": "d",
                       "æ": "a", "œ": "o", "ß": "s", "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
                       "\u2212": "-"})   # letters with no decomposition, and the hyphens and dashes people type in names


def fold(s: str) -> str:
    """Same-length matching form: lower case, accents dropped ("José" -> "jose", "Søren" -> "soren"), typographic
    hyphens as "-", so rules built from the sheet's spelling match any case or accenting while match spans still index
    the original text."""
    out = []
    for c in s:
        d = unicodedata.normalize("NFKD", c)
        base = d[0] if d and not unicodedata.combining(d[0]) else c
        out.append((base.lower()[:1] or c).translate(_FOLD))
    return "".join(out)


def _view(s: str, camel: bool) -> tuple[str, list[int] | None]:
    """The text names are matched in, and where each of its characters stood in s (None when it is s itself).
    Invisible format characters and combining accents are left out, so a name broken by a zero-width space, or typed
    with separate accent marks, still matches. camel=True also puts a space where a lower-case letter meets a
    capital, so "XiaomingWangFinal.docx" reads as three words; the email rule reads the text without those spaces."""
    out: list[str] = []
    idx: list[int] = []
    changed, prev = False, ""
    for i, c in enumerate(s):
        if unicodedata.category(c) in _SKIP:
            changed = True
            continue
        if camel and c.isupper() and prev.islower():
            out.append(" ")
            idx.append(i)
            changed = True
        out.append(c)
        idx.append(i)
        prev = c
    return ("".join(out), idx) if changed else (s, None)


def _cell(v, short: bool = False) -> str:
    """A sheet cell worth masking, or '': "N/A", "None", "-" or a lone initial would mask pieces of every word.
    short=True keeps a 2-letter name ("Li"), which is only matched after a title ("Mr. Li")."""
    v = "".join(c for c in (v or "").strip() if unicodedata.category(c) not in _SKIP)
    if v.startswith("#"):   # a spreadsheet error ("#REF!", "#N/A", "#VALUE!") is no name
        return ""
    words = re.findall(r"[^\W\d_]+", fold(v))
    joined = " ".join(words)
    if not joined or joined in _PLACEHOLDERS or sum(map(len, words)) < (2 if short or not joined.isascii() else 3):
        return ""
    return v


def _latin_tokens(s: str, minlen: int) -> list[str]:
    return sorted({t for t in re.findall(r"[^\W\d_]+", fold(s), re.UNICODE) if len(t) >= minlen and t.isascii()},
                  key=lambda t: (-len(t), t))


def _name_tokens(s: str, minlen: int) -> list[str]:
    """A name's parts, plus two neighbouring parts joined when the sheet hyphenates them or the name has three or more
    parts: the sheet's "Yu-Ting Li" or "Yu Ting Li" is written "Yuting Li" in a paper. (Not for two-part names: "He
    Nan" joined is the province Henan.)"""
    toks = set(_latin_tokens(s, minlen))
    words = re.findall(r"[a-z]+|-", fold(s))
    parts = [w for w in words if w != "-"]
    for i in range(len(words) - 2):
        if words[i] != "-" and words[i + 1] == "-" and words[i + 2] != "-":
            toks.add(words[i] + words[i + 2])
    if len(parts) >= 3:
        toks.update(a + b for a, b in zip(parts, parts[1:]))
    return sorted((t for t in toks if len(t) >= minlen), key=lambda t: (-len(t), t))


def _alt(parts) -> str:
    return "|".join(sorted(set(parts), key=lambda p: (-len(p), p)))


def _tok(t: str, split: bool = False) -> str:
    """One name part. split=True lets a part of 4+ letters be broken by a space or hyphen, as pinyin often is
    ("Yu-Ting" or "Yu Ting" for "Yuting"); those rules also require the name to start with a capital (_namelike), so
    "to bias" is not Tobias."""
    return _BREAK.join(map(re.escape, t)) if split and len(t) >= 4 else re.escape(t)


def _seq(toks: list[str], sep: str = _SEP, split: bool = False) -> str:
    """Two or more parts of one name in a row, in any order, a middle initial allowed ("Mary Jane Watson", "Watson,
    Mary Jane", "John M. Smith"): a pair rule would leave the third part visible. Inside a full name even a 2-letter
    surname (Li, Wu, Xu) is masked; alone it is not, so "Li" the element or "Wu et al." stay readable."""
    if len(toks) < 2:
        return ""
    t = _alt(_tok(x, split) for x in toks)
    return rf"(?:{t})(?:{sep}(?:[a-z]\.\s*)?(?:{t}))+"


def _glued(toks: list[str]) -> list[str]:
    """Two name parts written as one word ("weili", "josenunez"): kept to addresses, handles and file names
    (_handle), since "Wuhan", "human" or "yuan" can be two short name parts glued."""
    return [rf"{re.escape(a)}{re.escape(b)}" for a in toks for b in toks if a != b]


def _initials(toks: list[str]) -> list[str]:
    """"W. Li", "Li W.", "Li, W.": an initial needs its full stop, so a stray letter beside a name part is not one."""
    return [p for a in toks for b in toks if a != b
            for p in (rf"{re.escape(a[0])}\.\s*{re.escape(b)}", rf"{re.escape(b)},?\s*{re.escape(a[0])}\.")]


def _phrase(v: str) -> str:
    """A whole sheet cell, letter-edged on each side that is a Latin letter: "Dr. Li" is not inside "Dr. Lin", but
    北京四中 is still found inside 就读于北京四中."""
    f = fold(v)
    pre = _NB if f[:1].isascii() and f[:1].isalpha() else ""
    post = _NA if f[-1:].isascii() and f[-1:].isalpha() else ""
    return pre + re.escape(f) + post


def _cn_runs(name: str) -> list[str]:
    """The non-Latin runs of a cell (its Chinese name), spaces removed: "李四海 (Li Sihai)" gives 李四海."""
    s = "".join(c for c in fold(name) if not c.isspace())
    return [r for r in re.findall(r"[^\W\d_]{2,}", s) if not r.isascii()]


def _cn_first(cell: str) -> list[str]:
    """The mentor's Chinese name: the first Chinese chunk of the cell outside brackets, a lone surname joined to the
    chunk after it. "张华 (数学)" or "张华 物理系" gives 张华, "张 华" or "李 四海" gives 张华 or 李四海."""
    cell = re.sub(r"\([^)]*\)|（[^）]*）|\[[^\]]*\]", " ", cell)
    chunks = [c for c in re.findall(r"[^\W\d_]+", fold(cell)) if not c.isascii()]
    if not chunks:
        return []
    name = chunks[0]
    for c in chunks[1:]:
        if len(name) > 1:
            break
        name += c
    return [name] if len(name) >= 2 else []


def _cn(runs: list[str], apart: bool = False) -> str | None:
    """Chinese names, matched with or without spaces between their characters. apart=True (classmates) matches a
    2-character name only where no Chinese character touches it, as 高原 or 田野 can be part of an ordinary word."""
    pats = []
    for r in runs:
        p = r"\s*".join(map(re.escape, r))
        pats.append(rf"(?<!{_CJK}){p}(?!{_CJK})" if apart and len(r) == 2 else p)
    return _alt(pats) or None


def _mentor_name(cell: str) -> str:
    """The mentor cell without its affiliation: a bracket or a part between commas or semicolons that names an
    institution ("Zhang Hua, Peking University", "Li Ming (Tsinghua University)"). Other brackets stay: "张华 (Hua
    Zhang)" is the name twice."""
    cell = re.sub(r"\([^)]*\)|（[^）]*）|\[[^\]]*\]",
                  lambda m: " " if _AFFILIATION.search(m.group(0)) else " " + m.group(0)[1:-1] + " ", cell)
    return ", ".join(p for p in re.split(r"[,;，；/]", cell) if not _AFFILIATION.search(p))


def _titled(s: str, a: int, b: int) -> bool:
    """Every word of the match is capitalised in the original text, as a name is when it is a name ("Xiao-ming"
    counts as one word)."""
    return all(w[:1].isupper() for w in re.split(r"[\s_+,]+", s[a:b]) if w)


def _named(s: str, a: int, b: int) -> bool:
    """The last word of the match (the surname after a title or role word) is capitalised: "the supervisor long ago",
    "doctor he" or "500 ms an" is not the mentor."""
    words = [w for w in re.split(r"[\s.]+", s[a:b]) if w]
    return bool(words) and words[-1][:1].isupper()


def _spaced(s: str, a: int, b: int) -> bool:
    """A name made only of 2-letter parts is joined by plain spaces: "Li Na" is the student, "Li, Na" and "Na-Li"
    are chemistry."""
    words = re.findall(r"[^\W\d_]+", s[a:b])
    return any(len(w) > 2 for w in words) or not re.search(r"[,.\-_+]", s[a:b])


def _handle(s: str, a: int, b: int) -> bool:
    """The match sits in an address, a handle or a file name: "github.com/weili", "weili.com", "josenunez7"."""
    before = a > 0 and s[a - 1] in _HANDLE
    after = b < len(s) and (s[b] in "/@_+#" or s[b].isdigit() or (s[b] == "." and b + 1 < len(s) and s[b + 1].isalnum()))
    return before or after


def _namelike(s: str, a: int, b: int) -> bool:
    """Written as a name: starting with a capital, or in a handle."""
    return s[a].isupper() or _handle(s, a, b)


def _spaced_name(s: str, a: int, b: int) -> bool:
    return _namelike(s, a, b) and _spaced(s, a, b)


def _finds(rx: re.Pattern, f: str, v: str, keep) -> list[tuple[int, int]]:
    """The spans of rx in f that keep accepts. When keep turns a match down, the search resumes one character later,
    so a rejected "long Chen" cannot hide the classmate "Chen Jie" right after it."""
    if keep is None:
        return [m.span() for m in rx.finditer(f) if m.end() > m.start()]
    out, pos = [], 0
    while (m := rx.search(f, pos)) is not None:
        a, b = m.span()
        if b > a and keep(v, a, b):
            out.append((a, b))
            pos = b
        else:
            pos = a + 1
    return out


def _fresh(spans: list[tuple[int, int]], new: list[tuple[int, int]]) -> int:
    """How many of new (sorted) overlap none of spans (sorted, disjoint)."""
    n = i = 0
    for a, b in new:
        while i < len(spans) and spans[i][1] <= a:
            i += 1
        if i == len(spans) or spans[i][0] >= b:
            n += 1
    return n


def _merge(spans: list[tuple[int, int]], new: list[tuple[int, int]]) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for a, b in sorted(spans + new):   # two sorted runs: a linear merge
        if out and a < out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


class Redactor:
    """PII scrubber: drops front matter (except the title) and any acknowledgments section, and masks sheet-driven
    names/school/email everywhere including footnotes, matching case- and accent-insensitively.

    The paper's own row: its full name (any order and any number of parts, separated by spaces or punctuation),
    initial + name part ("W. Li"), each name part of 3+ letters alone, a 2-letter part where it is cited ("(Li,
    2024)", "Li (2024)", "Li et al."), a capitalised name part split by a space or hyphen ("Xiao-Ming" for
    "Xiaoming"), two parts glued inside an address or file name, and its CN name (spaces allowed between characters),
    also when the sheet put it in the EN column. The mentor: the whole cell (when it has two name parts or a CN name), the full
    name, a title + capitalised surname ("Professor Smith", "Dr.Smith"), a role + capitalised surname ("my mentor
    Smith"), surname + laoshi, or the CN surname + 老师; a 2-letter surname only after a title, role or laoshi; an
    affiliation in the cell is not part of the name. The school: the whole cell, and its distinctive capitalised
    words (not "High", "School" or a city). Any email. Every other row on the round's sheet: capitalised full EN
    names and CN names only, so a classmate named in a paper is masked without blanking common words, places or
    chemistry. A placeholder cell ("N/A", "None") masks nothing. Invisible format characters or separate accent marks
    inside a name do not hide it, and a name typed against Chinese text with no space is still found.
    `.paras` is index-aligned with doc.paras (dropped -> ''); `.dropped` holds the dropped paragraph indices;
    `.scrub` masks arbitrary strings."""

    def __init__(self, doc: Doc, row: dict | None, others: list[dict] | None = None):
        self._rules = self._build_rules(row or {}, others or [])
        self.report: dict[str, int] = {}
        self.dropped: set[int] = set()
        self.paras, self.footnotes, self.text = self._apply(doc)

    def _build_rules(self, row: dict, others: list[dict]) -> list[tuple[re.Pattern, str, object, bool]]:
        rules: list[tuple[re.Pattern, str, object, bool]] = []

        def add(pattern: str | None, kind: str, edges: bool = True, keep=None) -> None:
            if pattern:
                rules.append((re.compile(rf"{_NB}(?:{pattern}){_NA}" if edges else pattern), kind, keep, True))

        school = _cell(row.get("school"))
        mentor = _cell(row.get("mentor"), short=True)
        cn = _cell(row.get("cn_name"))
        en = _cell(row.get("en_name"))
        rules.append((_EMAIL, "email", None, False))   # first, so a whole address masks as one unit (its local part is often a name token)
        # Whole phrases before single tokens, so a phrase is masked (and counted) once.
        if school and (len(_latin_tokens(school, 2)) >= 2 or _cn_runs(school)):
            add(_phrase(school), "school", edges=False)
        if mentor:
            name = _mentor_name(mentor)
            toks = [t for t in _name_tokens(name, 2) if t not in _NOT_NAMES]
            cn_mentor = _cn_first(mentor)   # a subject after the name (张华 物理系) is not the name
            if len(toks) >= 2 or cn_mentor:   # a one-word cell ("Independent", "Teacher") is not a name to mask everywhere
                add(_phrase(mentor), "mentor", edges=False)
            add(_cn(cn_mentor), "mentor", edges=False)
            if cn_mentor:
                add(rf"(?:{_alt(map(re.escape, {cn_mentor[0][:1], cn_mentor[0][:2]}))}){_CN_HONORIFIC}", "mentor", edges=False)
            add(_seq(toks), "mentor", keep=_spaced)
            add(_seq(toks, split=True), "mentor", keep=_spaced_name)
            add(_alt(_glued([t for t in toks if len(t) >= 2])), "mentor", keep=_handle)
            if toks:
                surnames = _alt(map(_tok, toks))
                add(rf"{_TITLE}(?:{surnames}){_CITED}", "mentor", keep=_named)
                add(rf"{_ROLE}(?:{surnames}){_CITED}", "mentor", keep=_named)
                add(rf"(?:导师|老师|教授|博士)\s*(?:{surnames}){_CITED}", "mentor", keep=_named)   # "导师 Zhang"
                add(rf"{_NB}(?:{surnames}){_HONORIFIC}", "mentor", edges=False)
        add(_cn(_cn_runs(cn)), "cn_name", edges=False)
        add(_cn(_cn_runs(en)), "en_name", edges=False)   # a Chinese (or other non-Latin) name typed in the EN column
        own = _name_tokens(en, 2)
        self._own = {*own, *_cn_runs(cn), *_cn_runs(en)}
        short = [t for t in own if len(t) == 2]   # "Li" alone blanks words; as a cited author it is the student
        add(rf"(?:{_alt(map(re.escape, short))})(?=\s*(?:,\s*\d{{4}}|\(\d{{4}}|et\.?\s+al))" if short else None,
            "en_name", keep=_titled)
        add(_seq(own), "en_name", keep=_spaced)
        add(_seq(own, split=True), "en_name", keep=_spaced_name)
        add(_alt(_glued(own)), "en_name", keep=_handle)
        add(_alt(_initials(own)), "en_name")
        add(_alt(map(re.escape, _name_tokens(en, 3))), "en_name")
        add(_alt(_tok(t, split=True) for t in _name_tokens(en, 4)), "en_name", keep=_namelike)
        names = [_name_tokens(_cell(o.get("en_name")), 2) for o in others]
        add(_alt(_seq(toks, _GAP, split=True) for toks in names if len(toks) >= 2), "other_name", keep=_titled)
        add(_alt(rf"{re.escape(a)}(?:,\s*|-){re.escape(b)}" for toks in names for a in toks for b in toks
                 if a != b and len(a) >= 3 and len(b) >= 3), "other_name", keep=_titled)   # "Chen, Yuting", "Haoran-Liu"
        add(_cn([r for o in others for r in _cn_runs(_cell(o.get("cn_name")))], apart=True), "other_name", edges=False)
        if school and _SCHOOL_WORDS.search(school):
            words = [t for t in _latin_tokens(school, 4) if t not in _SCHOOL_GENERIC and t not in _PLACES]
            add(_alt(map(re.escape, words)), "school", keep=_titled)
        return rules

    def _mask(self, s: str, count: bool) -> str:
        if not s:
            return s
        views: dict[bool, tuple[str, str, list[int] | None]] = {}
        spans: list[tuple[int, int]] = []   # sorted, disjoint: everything masked so far, as positions in s
        for rx, kind, keep, camel in self._rules:
            if camel not in views:
                v, idx = _view(s, camel)
                views[camel] = (v, fold(v), idx)
            v, f, idx = views[camel]
            new = _finds(rx, f, v, keep)
            if not new:
                continue
            if idx is not None:   # back to positions in s; a mask also covers the left-out characters inside it
                new = [(idx[a], idx[b - 1] + 1) for a, b in new]
            if count:   # a match inside an earlier (longer, more specific) rule's mask is not counted again
                n = _fresh(spans, new)
                if n:
                    self.report[kind] = self.report.get(kind, 0) + n
            spans = _merge(spans, new)   # but it still widens the mask, so a short rule cannot shield a longer name
        if not spans:
            return s
        out, pos = [], 0
        for a, b in spans:
            out += [s[pos:a], MASK]
            pos = b
        out.append(s[pos:])
        return "".join(out)

    def scrub(self, s: str) -> str:
        return self._mask(s, count=False)

    def scrub_key(self, key: str) -> str:
        """A citation key ("surname:year"): masked whole when the surname is one of the student's own name parts,
        however short, since the key says that this author is cited."""
        surname, sep, rest = key.partition(":")
        if fold(surname) in self._own:
            return MASK + sep + rest
        return self.scrub(key)

    def _count(self, s: str) -> str:
        return self._mask(s, count=True)

    def _drop_ranges(self, doc: Doc) -> tuple[int, set[int], tuple[int, int] | None]:
        # First canonical heading ends the front matter (cap 40); title = first non-empty paragraph.
        cut = FRONT_MATTER_CAP
        for i, p in enumerate(doc.paras):
            if i >= FRONT_MATTER_CAP:
                break
            if p.text.strip() and headings.canon(p.text) is not None:
                cut = i
                break
        title = next((i for i, p in enumerate(doc.paras) if p.text.strip()), None)
        front = {i for i in range(min(cut, len(doc.paras))) if doc.paras[i].text.strip() and i != title}
        ack = None
        for i, p in enumerate(doc.paras):
            if p.text.strip() and headings.canon(p.text) == "acknowledgments":
                end = len(doc.paras)
                for j in range(i + 1, len(doc.paras)):
                    if doc.paras[j].text.strip() and headings.canon(doc.paras[j].text) is not None:
                        end = j
                        break
                ack = (i, end)
                break
        return title, front, ack

    def _apply(self, doc: Doc) -> tuple[list[str], list[str], str]:
        title, front, ack = self._drop_ranges(doc)
        self.dropped = set(front) | (set(range(*ack)) if ack else set())
        out: list[str] = []
        for i, p in enumerate(doc.paras):
            if i in front:
                if p.text.strip():
                    self.report["front_matter"] = self.report.get("front_matter", 0) + 1
                out.append("")
            elif ack and ack[0] <= i < ack[1]:
                if p.text.strip():
                    self.report["acknowledgments"] = self.report.get("acknowledgments", 0) + 1
                out.append("")
            else:
                out.append(self._count(p.text))
        footnotes = [self._count(f) for f in doc.footnotes]
        text = "\n".join(t for t in out if t)
        if footnotes:
            text += "\n" + "\n".join(f for f in footnotes if f)
        return out, footnotes, text


def build(doc: Doc, row: dict | None, others: list[dict] | None = None) -> Redactor:
    return Redactor(doc, row, others)


def names_known(row: dict | None) -> bool:
    """Whether a sheet row gives redaction a rule for the student's own name: Latin name parts or a Chinese name, in
    either name column. A placeholder ("N/A") or a script the rules do not cover counts as no name."""
    if not row:
        return False
    en, cn = _cell(row.get("en_name")), _cell(row.get("cn_name"))
    return bool(_name_tokens(en, 2) or _cn_runs(en) or _cn_runs(cn))
