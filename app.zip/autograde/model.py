from __future__ import annotations

from dataclasses import asdict, dataclass, field

METRICS = ("structure", "citations", "resolvability", "relevancy", "numbers", "figures")
STATUSES = ("ok", "partial", "not_applicable", "skipped")

# Every finding code the checks can report, by metric. A deduction costs the weight its program's rubric gives it
# (rubric/<program>.toml, [weights]); a look item only asks a person to look and never costs points.
DEDUCTIONS: dict[str, tuple[str, ...]] = {
    "structure": ("missing_required", "out_of_order", "abstract_length", "abstract_unlabeled"),
    "citations": ("dangling", "uncited_entry", "mixed_styles", "duplicate_entry", "no_reference_list",
                  "no_in_text_citations", "footnote_empty", "footnote_order"),
    "resolvability": ("doi_dead", "doi_other_work"),
    "relevancy": ("off_topic",),
    "numbers": ("absent_from_source",),
    "figures": ("numbering_gap", "unreferenced_caption", "reference_without_caption"),
}
LOOKS: dict[str, tuple[str, ...]] = {
    "structure": ("missing_expected", "unclassified_heading", "cjk_share"),
    "citations": ("year_mismatch", "incomplete_entry", "bracket_numbers_no_numbered_list", "uncited_entry"),
    "resolvability": ("unverified", "year_mismatch"),
    "numbers": ("unverifiable",),
    "figures": ("images_without_captions",),
}
UNWEIGHED = 0.0   # a deduction's weight until rubric.score sets it from the rubric


class Unparsed(Exception):
    """The submission could not be read as .docx; the batch continues."""


@dataclass(slots=True)
class Para:
    i: int              # ordinal among body paragraphs outside tables; the stage-2 anchor
    text: str
    style: str = ""
    bold: bool = False
    num: str | None = None   # leading numbering text, or "auto" for w:numPr
    heading: bool = False


@dataclass(slots=True)
class Doc:
    paras: list[Para]
    tables: list[list[str]] = field(default_factory=list)
    footnotes: list[str] = field(default_factory=list)
    media: int = 0
    words: int = 0
    hyperlinks: list[str] = field(default_factory=list)

    def text(self) -> str:
        return "\n".join(p.text for p in self.paras)


@dataclass(slots=True)
class Ref:
    i: int                      # 1-based position in the reference list
    raw: str
    para: int                   # paragraph where the entry starts
    num: int | None = None      # numbered-list label, if any
    doi: str | None = None
    url: str | None = None
    year: int | None = None
    names: list[str] = field(default_factory=list)   # capitalized author tokens, particles included
    title: str = ""
    cited: int = 0
    found: dict | None = None   # {source, id, title, year, abstract, oa_url} once resolved


@dataclass(slots=True)
class Marker:
    para: int
    text: str                   # the sentence containing the in-text citation
    key: str                    # "surname:year" or "n:12"
    entries: list[int] = field(default_factory=list)   # candidate Ref.i values; >1 = ambiguous, 0 = dangling
    near: list[int] = field(default_factory=list)      # same author, different year: a look item, never a deduction


@dataclass(slots=True)
class Finding:
    code: str                   # "<metric>.<code>"
    weight: float
    para: int | None            # None = document-level
    quote: str
    note: str


@dataclass(slots=True)
class Metric:
    name: str
    score: float | None
    findings: list[Finding] = field(default_factory=list)
    look: list[Finding] = field(default_factory=list)
    rationale: str = ""
    status: str = "ok"


def to_dict(obj) -> dict:
    return asdict(obj)
