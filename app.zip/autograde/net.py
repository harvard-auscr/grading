from __future__ import annotations

import http.client
import ipaddress
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

UA = "hauscr-auto-grader/0.1 (mailto:tech@hauscr.org)"
CAP = 2_000_000
TIMEOUT = 20
_last = 0.0
# The in-browser build (browser/entry.py) sets this: a page has no sockets, so requests go out through the browser,
# which refuses every host outside its list. TRANSPORT(method, url, follow=, headers=, data=, timeout=) returns
# (status, content-type, body).
TRANSPORT = None


class NetError(Exception):
    pass


def _bad_ip(addr: str) -> bool:
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return True
    return (ip.is_private or ip.is_loopback or ip.is_link_local
            or ip.is_reserved or ip.is_multicast or ip.is_unspecified)


def _safe_host(host: str) -> bool:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    return bool(infos) and not any(_bad_ip(info[4][0]) for info in infos)


def _check_peer(sock) -> None:
    """DNS rebinding: the name passed _safe_host, but the socket may have landed somewhere private."""
    try:
        peer = sock.getpeername()[0]
    except OSError as e:
        sock.close()
        raise NetError("no peer address") from e
    if _bad_ip(peer):
        sock.close()
        raise NetError(f"refused peer {peer}")


class _GuardedHTTP(http.client.HTTPConnection):
    def connect(self):
        super().connect()
        _check_peer(self.sock)


class _GuardedHTTPS(http.client.HTTPSConnection):
    def connect(self):
        super().connect()
        _check_peer(self.sock)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class _HTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_GuardedHTTP, req)


class _HTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_GuardedHTTPS, req)


_opener = urllib.request.build_opener(_NoRedirect, _HTTPHandler, _HTTPSHandler)


def _pace(rate: float) -> None:
    global _last
    wait = rate - (time.monotonic() - _last)
    if wait > 0:
        time.sleep(wait)
    _last = time.monotonic()


def get(url: str, *, follow: int = 3, method: str = "GET", rate: float = 0.25) -> tuple[int, str, bytes]:
    """(status, content-type, body) with SSRF guard, manual redirects, streamed byte cap, polite rate."""
    if TRANSPORT is not None:   # the browser follows redirects itself and checks the host against its list
        u = urllib.parse.urlsplit(url)
        if u.scheme != "https" or not u.hostname:
            raise NetError(f"refused {url[:80]}")
        _pace(rate)
        status, ctype, body = TRANSPORT(method, url, follow=follow)
        return status, ctype, (body if method != "HEAD" else b"")[:CAP]
    for _ in range(follow + 1):
        u = urllib.parse.urlsplit(url)
        if u.scheme not in ("http", "https") or not u.hostname or not _safe_host(u.hostname):
            raise NetError(f"refused {url[:80]}")
        _pace(rate)
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"}, method=method)
        try:
            with _opener.open(req, timeout=TIMEOUT) as r:
                body = r.read(CAP + 1) if method != "HEAD" else b""
                status, ctype, loc = r.status, r.headers.get("Content-Type", ""), r.headers.get("Location")
        except urllib.error.HTTPError as e:
            status, ctype, loc, body = e.code, e.headers.get("Content-Type", ""), e.headers.get("Location"), b""
        except (urllib.error.URLError, socket.timeout, TimeoutError, OSError) as e:
            raise NetError(str(e)[:120]) from e
        if status in (301, 302, 303, 307, 308) and loc and follow:
            url, follow = urllib.parse.urljoin(url, loc), follow - 1
            continue
        return status, ctype, body[:CAP]
    return status, ctype, body[:CAP]


def status_only(url: str) -> int:
    """First-hop status with redirects NOT followed: 30x proves a DOI is registered without touching the publisher."""
    return get(url, follow=0, method="HEAD")[0]
