from __future__ import annotations

import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from . import headings
from .model import Doc, Para, Unparsed

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
MC = "{http://schemas.openxmlformats.org/markup-compatibility/2006}"
REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"
M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"
MAX_XML_BYTES = 40 * 2**20   # document.xml, uncompressed; a long paper with tables is a few MB
MAX_PARAS = 20000            # a long paper is about 1,000
MAX_PART_BYTES = 10 * 2**20  # styles, footnotes, links: a long paper's are well under 1 MB
MAX_FOOTNOTES = 5000
MAX_ELEMENTS = 3_000_000     # XML elements in document.xml; a long paper with tables has well under 500,000
MAX_OPEN_FIELDS = 64         # fields open at once in one paragraph; real nesting is a few deep
_XML_ERRORS = (ET.ParseError, LookupError, ValueError)   # an unknown or multi-byte declared encoding is not a ParseError

# Field instructions whose RESULT run (between fldChar separate and end) is chrome, not text.
_FIELD_DROP = ("PAGE", "NUMPAGES", "PAGEREF", "SECTIONPAGES", "TOC")
_TOC_LINE = re.compile(r"(?:\t|\.{3,})\s*\d{1,3}\s*$")   # manual TOC entry: "Intro\t4" / "Intro....4"; run on a line's tail
_NUM_LEAD = re.compile(r"^\s*(\d+(?:\.\d+)*|[IVXLC]+)[.)]?\s+")
_HEAD_STYLE = re.compile(r"heading|title|标题", re.I)


def _grp(s: str) -> str:
    return s if re.fullmatch(r"[\w.]*", s) else f"({s})"


def _math(el) -> str:
    """Linear text of an Office Math (OMML) element: fractions as (a)/(b), scripts as x^(2) / x_(i). Without this every
    equation, and every symbol typed in equation mode, vanished from the text."""
    tag = el.tag

    def part(name):
        c = el.find(M + name)
        return "".join(_math(x) for x in c) if c is not None else ""

    if tag == M + "t":
        return el.text or ""
    if tag == M + "f":
        return f"{_grp(part('num'))}/{_grp(part('den'))}"
    if tag == M + "sSup":
        return f"{part('e')}^{_grp(part('sup'))}"
    if tag == M + "sSub":
        return f"{part('e')}_{_grp(part('sub'))}"
    if tag == M + "sSubSup":
        return f"{part('e')}_{_grp(part('sub'))}^{_grp(part('sup'))}"
    if tag == M + "rad":
        deg = part("deg")
        return f"{deg + '√' if deg else '√'}{_grp(part('e'))}"
    if tag in (M + "d", M + "nary"):
        pr = el.find(M + ("dPr" if tag == M + "d" else "naryPr"))
        def val(n, dflt):   # an element without its m:val attribute keeps the default
            e = pr.find(M + n) if pr is not None else None
            v = e.get(M + "val") if e is not None else None
            return dflt if v is None else v
        if tag == M + "d":
            sep = val("sepChr", ",")
            return val("begChr", "(") + sep.join("".join(_math(x) for x in e) for e in el.findall(M + "e")) + val("endChr", ")")
        sub, sup = part("sub"), part("sup")
        return val("chr", "∫") + (f"_{_grp(sub)}" if sub else "") + (f"^{_grp(sup)}" if sup else "") + " " + part("e")
    if tag.endswith("Pr"):
        return ""
    return "".join(_math(c) for c in el)


def _drop_instr(instr: str) -> bool:
    tok = instr.strip().split()
    return bool(tok) and tok[0].upper() in _FIELD_DROP


def _bold_run(r) -> bool:
    rpr = r.find(f"{W}rPr")
    if rpr is None:
        return False
    b = rpr.find(f"{W}b")
    return b is not None and (b.get(f"{W}val") or "true") not in ("0", "false", "off")


def _sup_run(r) -> bool:
    rpr = r.find(f"{W}rPr")
    va = rpr.find(f"{W}vertAlign") if rpr is not None else None
    return va is not None and va.get(f"{W}val") == "superscript"


class _P:
    """Accumulates one paragraph's text while a document-order walk feeds it runs and fields."""

    __slots__ = ("out", "fields", "runs", "toc_net", "orphan_ends", "math", "drops")

    def __init__(self, math: bool = False):
        self.math = math                 # read Office Math as linear text (off for the mechanical checks)
        self.out: list[str] = []
        self.fields: list[dict] = []     # open field stack: {phase, instr, drop, toc}
        self.runs: list[bool] = []       # bold flag per visible-text run
        self.toc_net = 0                 # TOC field begins minus ends in this paragraph
        self.orphan_ends = 0             # field ends with nothing open here: they close a field begun in an earlier paragraph
        self.drops = 0                   # open fields whose result is chrome (page numbers, TOC): counted, not rescanned

    def dropping(self) -> bool:
        return self.drops > 0


def _walk(el, p: _P) -> None:
    for c in el:
        tag = c.tag
        if tag in (f"{W}del", f"{MC}Fallback"):
            continue
        if tag == f"{W}instrText":
            if p.fields and p.fields[-1]["phase"] == "instr":
                p.fields[-1]["instr"].append(c.text or "")   # joined at "separate": no quadratic string growth
            continue
        if tag == f"{W}delText":
            continue
        if tag == M + "oMath":
            if p.math and not p.dropping():
                p.out.append(_math(c))
            continue
        if tag == f"{W}fldChar":
            ft = c.get(f"{W}fldCharType")
            if ft == "begin":
                if len(p.fields) >= MAX_OPEN_FIELDS:
                    raise Unparsed(f"over {MAX_OPEN_FIELDS} open fields in a paragraph")
                p.fields.append({"phase": "instr", "instr": [], "drop": False, "toc": False})
            elif ft == "separate" and p.fields and p.fields[-1]["phase"] == "instr":
                f = p.fields[-1]
                f["phase"] = "result"
                f["instr"] = "".join(f["instr"])
                f["drop"] = _drop_instr(f["instr"])
                f["toc"] = f["instr"].strip().upper().startswith("TOC")
                if f["drop"]:
                    p.drops += 1
                if f["toc"]:
                    p.toc_net += 1
            elif ft == "end" and p.fields:
                f = p.fields.pop()
                if f["phase"] == "result" and f["drop"]:
                    p.drops -= 1
                if f["toc"]:
                    p.toc_net -= 1
            elif ft == "end":
                p.orphan_ends += 1
            continue
        if tag == f"{W}fldSimple":
            if _drop_instr(c.get(f"{W}instr") or ""):
                continue
            _walk(c, p)
            continue
        drop = p.dropping()
        if tag == f"{W}tab":
            if not drop:
                p.out.append("\t")
        elif tag == f"{W}br" or tag == f"{W}cr":
            if not drop:
                p.out.append("\n")
        elif tag == f"{W}t":
            if not drop:
                p.out.append(c.text or "")
        elif tag == f"{W}footnoteReference":
            fid = c.get(f"{W}id")
            if not drop and fid:
                p.out.append(f"⟦fn:{fid}⟧")
        elif tag == f"{W}r":
            _run(c, p)
        else:
            _walk(c, p)


def _run(r, p: _P) -> None:
    if _sup_run(r):
        digits = "".join(t.text or "" for t in r.iter(f"{W}t")).strip()
        has_ctrl = any(e.tag in (f"{W}fldChar", f"{W}footnoteReference") for e in r.iter())
        if digits.isdigit() and not has_ctrl and not p.dropping():
            p.out.append(f"⟦sup:{digits}⟧")
            return
    vis = "".join(t.text or "" for t in r.iter(f"{W}t"))
    has_field = any(e.tag == f"{W}fldChar" for e in r.iter())
    if vis.strip() and not has_field and not p.dropping():
        p.runs.append(_bold_run(r))
    _walk(r, p)


def _para_text(pel, math: bool = False) -> tuple[str, list[bool], int, int]:
    p = _P(math)
    _walk(pel, p)
    return "".join(p.out), p.runs, p.toc_net, p.orphan_ends


def _cell_text(tc) -> str:
    parts = []
    for pel in tc.findall(f"{W}p"):
        raw = _para_text(pel)[0]
        parts.append(raw.replace("\t", " ").strip())
    return " ".join(x for x in parts if x).strip()


def _table_cells(tbl) -> list[str]:
    cells = []
    for tr in tbl.findall(f"{W}tr"):
        for tc in tr.findall(f"{W}tc"):
            cells.append(_cell_text(tc))
    return cells


def _sdt_is_toc(sdt) -> bool:
    pr = sdt.find(f"{W}sdtPr")
    if pr is None:
        return False
    return any(g.get(f"{W}val") == "Table of Contents" for g in pr.iter(f"{W}docPartGallery"))


def _part(z, name: str, cap: int | None = None) -> bytes:
    """One zip part, unpacked no further than cap + 1 bytes and refused past cap; KeyError when it is absent. The
    size the zip states is not trusted: zipfile's read() unpacks a whole stream before trimming it to that size.
    Only stored or deflated parts are read (Word writes deflate): zipfile unpacks bzip2, LZMA and zstd a whole block
    at a time whatever is asked for. A part that is not UTF-8 or declares a DTD is refused: Word writes neither, and
    a DTD's entities can multiply the text far past the cap."""
    cap = MAX_PART_BYTES if cap is None else cap
    short = name.rsplit("/", 1)[-1]
    info = z.getinfo(name)
    if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
        raise Unparsed(f"{short}: unsupported compression")
    try:
        with z.open(info) as f:
            data = f.read(cap + 1)
    except Exception as e:  # noqa: BLE001 - zipfile raises many types for a malformed entry; the message can quote it
        raise Unparsed(f"bad zip: {type(e).__name__}") from e
    if len(data) > cap:
        raise Unparsed(f"{short} over {cap // 2**20} MB")
    if data[:2] in (b"\xff\xfe", b"\xfe\xff") or b"\x00" in data[:64]:
        raise Unparsed(f"{short} is not UTF-8")
    if b"<!DOCTYPE" in data or b"<!ENTITY" in data:
        raise Unparsed(f"{short} declares a DTD")
    return data


def _styles_map(z) -> dict[str, str]:
    try:
        root = ET.fromstring(_part(z, "word/styles.xml"))
    except (KeyError, *_XML_ERRORS):
        return {}
    out = {}
    for s in root.iter(f"{W}style"):
        sid = s.get(f"{W}styleId")
        nm = s.find(f"{W}name")
        if sid and nm is not None:
            out[sid] = nm.get(f"{W}val") or ""
    return out


def _footnotes(z) -> list[str]:
    try:
        root = ET.fromstring(_part(z, "word/footnotes.xml"))
    except (KeyError, *_XML_ERRORS):
        return []
    skip = {"separator", "continuationSeparator", "continuationNotice"}
    items = []
    notes = root.findall(f"{W}footnote")
    if len(notes) > MAX_FOOTNOTES:
        raise Unparsed(f"over {MAX_FOOTNOTES} footnotes")
    for fn in notes:
        if fn.get(f"{W}type") in skip:
            continue
        try:
            fid = int(fn.get(f"{W}id"))
        except (TypeError, ValueError):
            continue
        if fid < 1:
            continue
        txt = " ".join(_para_text(pel)[0].replace("\t", " ").strip() for pel in fn.findall(f"{W}p"))
        items.append((fid, re.sub(r"\s+", " ", txt).strip()))
    return [t for _, t in sorted(items)]


def _hyperlinks(z) -> list[str]:
    try:
        root = ET.fromstring(_part(z, "word/_rels/document.xml.rels"))
    except (KeyError, *_XML_ERRORS):
        return []
    out = set()
    for rel in root.findall(f"{REL}Relationship"):
        if rel.get("Type", "").endswith("/hyperlink") and rel.get("TargetMode") == "External":
            tgt = rel.get("Target")
            if tgt:
                out.add(tgt)
    return sorted(out)


def read(path: Path | str, *, math: bool = False) -> Doc:
    """math=True keeps equations as linear text (for a human or model reading the paper); the mechanical checks leave
    them out, as they always have, so equation fragments never read as claims, citations or headings."""
    path = Path(path)
    if path.suffix.lower() != ".docx":
        raise Unparsed(f"unsupported extension {path.suffix!r}")
    try:
        z = zipfile.ZipFile(path)
    except Exception as e:  # noqa: BLE001 - a malformed header raises many types; the message can quote names inside
        raise Unparsed(f"bad zip: {type(e).__name__}") from e
    try:
        return _read(z, math)
    except RecursionError as e:
        raise Unparsed("nested too deep") from e
    finally:
        z.close()


def _read(z, math: bool) -> Doc:
    try:
        xml = _part(z, "word/document.xml", MAX_XML_BYTES)
    except KeyError as e:
        raise Unparsed(f"bad zip: {type(e).__name__}") from e
    try:
        root = ET.fromstring(xml)
    except _XML_ERRORS as e:
        raise Unparsed(f"bad xml: {str(e)[:80]}") from e
    if sum(1 for _ in root.iter()) > MAX_ELEMENTS:
        raise Unparsed(f"over {MAX_ELEMENTS} XML elements")

    body = root.find(f"{W}body")
    styles = _styles_map(z)
    paras: list[Para] = []
    tables: list[list[str]] = []
    toc_depth = 0        # open multi-paragraph TOC fields
    idx = 0
    seen_nonempty = False

    def emit_p(pel):
        nonlocal toc_depth, idx, seen_nonempty
        raw, runs, toc_net, orphan_ends = _para_text(pel, math)
        opened_in_toc = toc_depth > 0
        # A TOC field's end usually sits in a later paragraph than its begin, where the per-paragraph field stack
        # is empty; inside an open TOC such an end is the TOC closing, or the rest of the paper reads as TOC.
        toc_depth = max(0, toc_depth + toc_net - (orphan_ends if opened_in_toc else 0))
        if opened_in_toc:                      # inside a multi-paragraph TOC field result -> drop entirely
            return
        text = re.sub(r"[ \t]+", " ", raw.replace("\t", " ")).strip()
        text = re.sub(r" *\n *", "\n", text)
        style = _resolve_style(pel, styles)
        num = _num(pel, text)
        bold = bool(runs) and all(runs)
        title = not seen_nonempty and bool(text)
        heading = title or _is_heading(text, style, bold, num)
        if heading and not title and _TOC_LINE.search(raw[-200:]):   # heading-like manual TOC entry
            return
        if text:
            seen_nonempty = True
        paras.append(Para(i=idx, text=text, style=style, bold=bold, num=num, heading=heading))
        idx += 1
        if idx > MAX_PARAS:   # no real paper comes close; stop before building the rest
            raise Unparsed(f"over {MAX_PARAS} paragraphs")

    def walk_blocks(container):
        for c in container:
            if c.tag == f"{W}p":
                emit_p(c)
            elif c.tag == f"{W}tbl":
                tables.append(_table_cells(c))
            elif c.tag == f"{W}sdt":
                if _sdt_is_toc(c):
                    continue
                content = c.find(f"{W}sdtContent")
                if content is not None:
                    walk_blocks(content)

    if body is not None:
        walk_blocks(body)

    words = sum(len(p.text.split()) for p in paras)
    media = sum(1 for n in z.namelist() if n.startswith("word/media/"))
    doc = Doc(
        paras=paras,
        tables=tables,
        footnotes=_footnotes(z),
        media=media,
        words=words,
        hyperlinks=_hyperlinks(z),
    )
    return doc


def _resolve_style(pel, styles: dict[str, str]) -> str:
    ppr = pel.find(f"{W}pPr")
    if ppr is None:
        return ""
    st = ppr.find(f"{W}pStyle")
    if st is None:
        return ""
    val = st.get(f"{W}val") or ""
    return styles.get(val, val)


def _num(pel, text: str) -> str | None:
    m = _NUM_LEAD.match(text)
    if m:
        return m.group(1)
    ppr = pel.find(f"{W}pPr")
    if ppr is not None and ppr.find(f"{W}numPr") is not None:
        return "auto"
    return None


def _is_heading(text: str, style: str, bold: bool, num: str | None) -> bool:
    if not text:
        return False
    if _HEAD_STYLE.search(style):
        return True
    words = text.split()
    if len(words) <= 12 and not text.rstrip().endswith(".") and (bold or num):
        return True
    c = headings.canon(text)
    if c is not None and len(words) <= 6:
        return True
    return False
