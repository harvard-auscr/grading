from __future__ import annotations

import re

from autograde import headings
from autograde.model import Finding, Metric, UNWEIGHED

# Sections whose order is stable across disciplines. Methods/results/discussion float
# (Art Theory, Design Practice papers reorder them), so they stay out of the order check.
ORDER = ("abstract", "keywords", "introduction", "background", "conclusion", "references")
RANK = {n: i for i, n in enumerate(ORDER)}
INLINE_NAMES = ("abstract", "keywords", "references")

UNCLASSIFIED_CAP = 3

_CJK = re.compile(r"[぀-ヿ㐀-鿿豈-﫿ｦ-ﾟ]")
_WORD = re.compile(r"[0-9A-Za-z][0-9A-Za-z'’\-]*")
_ABS_LABEL = re.compile(r"^\s*(?:abstract|摘要)\s*[:：]?\s*", re.I)


def _wc(text: str) -> int:
    # each CJK char is a word; runs of latin/digits split on whitespace
    return len(_WORD.findall(text)) + len(_CJK.findall(text))


def run(doc, rubric: dict) -> Metric:
    conf = rubric["structure"]
    required = conf["required"]
    expected = conf["expected"]
    lo, hi = conf["abstract_words"]
    paras = doc.paras

    title_pos = next((i for i, p in enumerate(paras) if p.text.strip()), None)
    title_text = paras[title_pos].text.strip() if title_pos is not None else ""

    present: dict[str, int] = {}          # canonical name -> list position of first match
    inline_found: set[str] = set()
    unclassified: list = []
    for i, p in enumerate(paras):
        if i == title_pos or not p.text.strip():
            continue
        if p.heading:
            name = headings.canon(p.text)
            if name:
                present.setdefault(name, i)
            elif present:                       # front-matter lines (authors, school) are never quoted
                unclassified.append(p)
    # unstyled fallback: a first-line "Abstract"/"Keywords:"/"References" paragraph
    for name in INLINE_NAMES:
        if name in present:
            continue
        for i, p in enumerate(paras):
            if i == title_pos or not p.text.strip():
                continue
            if headings.inline(p.text, name):
                present[name] = i
                inline_found.add(name)
                break

    findings: list = []
    missing_req: list = []
    unlabeled = None if "abstract" in present else _unlabeled_abstract(present, paras, title_pos, lo, hi)
    for entry in required:
        if not any(a in present for a in entry.split("|")):
            if entry == "abstract" and unlabeled is not None:   # the abstract is there, only its heading is not
                findings.append(Finding("structure.abstract_unlabeled", UNWEIGHED,
                                        paras[unlabeled].i, paras[unlabeled].text.strip(),
                                        "abstract paragraph has no Abstract heading"))
                continue
            missing_req.append(entry)
            findings.append(Finding("structure.missing_required", UNWEIGHED,
                                    None, title_text, "no " + entry.replace("|", " or ")))
    ooo = _out_of_order(present, paras)
    if ooo:
        findings.append(ooo)
    alen = _abstract_length(present, inline_found, paras, lo, hi)
    if alen:
        findings.append(alen)

    look: list = []
    missing_exp = [e for e in expected if e not in present]
    for name in missing_exp:
        look.append(Finding("structure.missing_expected", 0.0, None, "", "no " + name))
    for p in unclassified[:UNCLASSIFIED_CAP]:
        look.append(Finding("structure.unclassified_heading", 0.0, p.i, p.text.strip(), "unrecognized heading"))
    cjk = _cjk_share(paras)
    if cjk:
        look.append(cjk)

    bits: list = []
    if missing_req:
        bits.append(f"{len(missing_req)} required missing")
    if unlabeled is not None and "abstract" not in present:
        bits.append("abstract unlabeled")
    if ooo:
        bits.append("out of order")
    if alen:
        bits.append("abstract length")
    if not findings:
        bits.append("all required present")
    return Metric("structure", None, findings=findings, look=look, rationale=", ".join(bits), status="ok")


def _unlabeled_abstract(present: dict[str, int], paras, title_pos, lo: int, hi: int) -> int | None:
    """Start of an abstract with no heading: the unheaded text between the byline and the first recognized
    section, at least half the minimum abstract length (scans split it into short lines). Only counts when a
    recognized section follows, so a paper with no headings at all never has an "abstract"."""
    if title_pos is None or not present:
        return None
    block = [k for k in range(title_pos + 1, min(present.values()))
             if paras[k].text.strip() and not paras[k].heading and not headings.inline(paras[k].text, "keywords")]
    if block and _wc(paras[block[0]].text) <= 20:     # the byline (author, school)
        block = block[1:]
    words = sum(_wc(paras[k].text) for k in block)
    return block[0] if block and lo / 2 <= words <= hi * 1.5 else None


def _out_of_order(present: dict[str, int], paras) -> Finding | None:
    seq = sorted((pos, RANK[n], n) for n, pos in present.items() if n in RANK)
    max_rank, prev = -1, None
    for pos, rank, name in seq:
        if rank < max_rank:   # `name` sits after `prev`, which canonically comes later
            return Finding("structure.out_of_order", UNWEIGHED, paras[pos].i,
                           paras[pos].text.strip(), f"{name} after {prev}")
        max_rank, prev = rank, name
    return None


def _abstract_length(present, inline_found, paras, lo, hi) -> Finding | None:
    if "abstract" not in present:
        return None
    pos = present["abstract"]
    if "abstract" in inline_found:
        body = _ABS_LABEL.sub("", paras[pos].text.strip())
    else:
        # body runs from just after the abstract heading to the next recognized section
        # (heading OR an inline keywords/references line), so a stray keywords line is excluded
        section_pos = {p for p in present.values() if p > pos}
        parts = []
        for k in range(pos + 1, len(paras)):
            p = paras[k]
            if (p.heading and p.text.strip()) or k in section_pos:
                break
            parts.append(p.text)
        body = " ".join(parts)
    n = _wc(body)
    if n and (n < lo or n > hi):   # 0 words = empty/parse gap, not a length infraction
        return Finding("structure.abstract_length", UNWEIGHED, paras[pos].i,
                       body.strip(), f"{n} words (want {lo}-{hi})")
    return None


def _cjk_share(paras) -> Finding | None:
    text = "".join(p.text for p in paras)
    total = len(re.findall(r"\S", text))
    if not total:
        return None
    cjk = len(_CJK.findall(text))
    if cjk / total > 0.05:
        return Finding("structure.cjk_share", 0.0, None, "", f"{round(100 * cjk / total)}% CJK characters")
    return None
