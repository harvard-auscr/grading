from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request

from . import net
from .cache import Cache

try:
    import anthropic
except Exception:   # SDK optional; the Anthropic route then has no client
    anthropic = None

MODEL = "claude-opus-5"   # Anthropic default; also the name oracle verdicts are cached under
# Provider -> (key variable, default model, base URL). Order is the preference when several keys are set.
PROVIDERS = {
    "deepseek": ("DEEPSEEK_API_KEY", "deepseek-flash", "https://api.deepseek.com"),
    "openai": ("OPENAI_API_KEY", "gpt-5.6-luna", "https://api.openai.com/v1"),
    "anthropic": ("ANTHROPIC_API_KEY", MODEL, None),
}
_FAMILIES = (("claude", "anthropic"), ("deepseek", "deepseek"), ("gpt", "openai"), ("chatgpt", "openai"),
             ("o1", "openai"), ("o3", "openai"), ("o4", "openai"))
_SYSTEM = "Reply with one json object and nothing else. It must conform to this JSON schema:\n"
_OPTIONAL = ("thinking", "reasoning_effort", "temperature")   # dropped once when an endpoint answers 400
_EFFORTS = ("low", "medium", "high", "xhigh", "max")


def effort() -> str:
    """LLM_EFFORT from .env: how much the model reasons before a verdict. Default low. Claude takes all five
    levels; the OpenAI-format endpoints top out at high, so xhigh and max are sent as high there."""
    e = (os.environ.get("LLM_EFFORT") or "").strip().lower()
    return e if e in _EFFORTS else "low"


def _chat_effort() -> str:
    e = effort()
    return "high" if e in ("xhigh", "max") else e
_TYPES = {"string": str, "integer": int, "number": (int, float), "boolean": bool}

# Running totals; grade.py reads the difference per paper and per run. metered = calls an API counted itself.
TALLY = dict.fromkeys(("calls", "metered", "tokens_in", "tokens_out", "tokens_reasoning", "tokens_in_cached",
                       "relevancy_calls", "relevancy_tokens_in", "numbers_calls", "numbers_tokens_in"), 0)
_USAGE = ("prompt_tokens", "completion_tokens", "reasoning_tokens", "cached_tokens")


PROMPT_RATE, VERDICT_RATE = 0.21, 0.29   # DeepSeek tokens per character, measured over the 11th-edition run


def est_tokens(text: str, rate: float = PROMPT_RATE) -> int:
    """Token estimate for traffic no API metered (oracle mode, cache hits). The rates are the DeepSeek
    tokenizer's measured figures for the corpus prompts (0.21) and the JSON verdicts (0.29), each within
    1%; 0.6 per wide (CJK) character is DeepSeek's published figure, unmeasured here: the prompts had none."""
    wide = sum(1 for ch in text if ord(ch) > 0x2E7F)
    return round(rate * (len(text) - wide) + 0.6 * wide)


def conforms(v, s: dict) -> bool:
    """The part of JSON Schema the metric schemas use: object/required/properties, array/items, enum, scalars."""
    t = s.get("type")
    if t == "object":
        props = s.get("properties", {})
        return (isinstance(v, dict) and all(k in v for k in s.get("required", []))
                and all(conforms(v[k], props[k]) for k in v if k in props))
    if t == "array":
        return isinstance(v, list) and all(conforms(x, s.get("items", {})) for x in v)
    if "enum" in s and v not in s["enum"]:
        return False
    return t not in _TYPES or (isinstance(v, _TYPES[t]) and (t == "boolean" or not isinstance(v, bool)))


class Chat:
    """An OpenAI-format chat endpoint (DeepSeek, OpenAI) over urllib: no SDK, so the frozen bundle gains
    nothing. OpenAI enforces the schema itself; DeepSeek only has JSON mode, so there the schema rides in
    the system message. Either way the reply is checked against the schema here."""

    def __init__(self, provider: str, key: str, model: str, base: str, thinking: bool = True):
        self.provider, self.key, self.model, self.thinking = provider, key, model, thinking
        self.url = base.rstrip("/") + "/chat/completions"
        self.status = None   # last HTTP status or exception type, for the run summary; never a body

    def _body(self, schema: dict, prompt: str) -> dict:
        user = {"role": "user", "content": prompt}
        if self.provider == "openai":
            return {"model": self.model, "messages": [user], "max_completion_tokens": 16000, "reasoning_effort": _chat_effort(),
                    "response_format": {"type": "json_schema",
                                        "json_schema": {"name": "verdict", "strict": True, "schema": schema}}}
        body = {"model": self.model, "messages": [{"role": "system", "content": _SYSTEM + json.dumps(schema)}, user],
                "temperature": 0, "response_format": {"type": "json_object"},
                "max_tokens": 16000 if self.thinking else 4000,
                "thinking": {"type": "enabled" if self.thinking else "disabled"}}
        if self.thinking:
            body["reasoning_effort"] = _chat_effort()
        return body

    def _post(self, body: dict) -> dict:
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {self.key}"}
        data = json.dumps(body).encode("utf-8")
        if net.TRANSPORT is not None:   # the in-browser build: the request goes out through the page's worker
            status, _ctype, raw = net.TRANSPORT("POST", self.url, follow=0, headers=headers, data=data, timeout=300)
            if status != 200:   # ask() reads only the code
                raise urllib.error.HTTPError(self.url, status, "", None, None)
            return json.loads(raw.decode("utf-8"))
        req = urllib.request.Request(self.url, data=data, method="POST", headers=headers)
        with urllib.request.urlopen(req, timeout=300) as r:
            return json.loads(r.read().decode("utf-8"))

    def ask(self, schema: dict, prompt: str) -> tuple[dict | None, dict]:
        body = self._body(schema, prompt)
        usage = dict.fromkeys(_USAGE, 0)
        for attempt in range(3):
            try:
                data = self._post(body)
            except urllib.error.HTTPError as e:
                self.status = e.code
                if e.code == 400 and any(k in body for k in _OPTIONAL):   # a model that rejects the extras
                    for k in _OPTIONAL:
                        body.pop(k, None)
                elif e.code in (429, 500, 502, 503, 504):
                    time.sleep(2 * (attempt + 1))
                else:                                        # 401 bad key, 402 no balance, 404 no such model
                    break
                continue
            except Exception as e:                           # timeout, DNS, TLS, a body that is not JSON
                self.status = type(e).__name__
                continue
            self.status = 200
            u = data.get("usage") or {}
            usage["prompt_tokens"] += int(u.get("prompt_tokens") or 0)
            usage["completion_tokens"] += int(u.get("completion_tokens") or 0)   # reasoning included, billed as output
            usage["reasoning_tokens"] += int((u.get("completion_tokens_details") or {}).get("reasoning_tokens") or 0)
            usage["cached_tokens"] += int(u.get("prompt_cache_hit_tokens")   # DeepSeek's name, then OpenAI's
                                          or (u.get("prompt_tokens_details") or {}).get("cached_tokens") or 0)
            try:
                choice = data["choices"][0]
                if choice["message"].get("refusal") or choice.get("finish_reason") == "content_filter":
                    break
                obj = json.loads(choice["message"]["content"])
            except Exception:
                continue                                     # JSON mode is documented to return empty content at times
            if conforms(obj, schema):
                return obj, usage
        return None, usage


def _has_key(p: str) -> bool:
    if p == "anthropic":
        return anthropic is not None and bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    return bool(os.environ.get(PROVIDERS[p][0]))


def provider() -> str | None:
    """The API the environment selects: LLM_PROVIDER, else the family LLM_MODEL belongs to, else the
    first provider with a key (DeepSeek, OpenAI, Anthropic). A named choice without its key selects nothing."""
    model = (os.environ.get("LLM_MODEL") or "").strip().lower()
    want = ((os.environ.get("LLM_PROVIDER") or "").strip().lower()
            or next((p for prefix, p in _FAMILIES if model.startswith(prefix)), ""))
    if want:
        return want if want in PROVIDERS and _has_key(want) else None
    return next((p for p in PROVIDERS if _has_key(p)), None)


def make_client():
    p = provider()
    if p is None:
        return None
    var, default, base = PROVIDERS[p]
    model = (os.environ.get("LLM_MODEL") or "").strip() or default
    if p == "anthropic":
        client = anthropic.Anthropic()
        client.model = model
        return client
    return Chat(p, os.environ[var], model, (os.environ.get("LLM_BASE_URL") or "").strip() or base,
                (os.environ.get("DEEPSEEK_THINKING") or "enabled").strip().lower() != "disabled")


def model_of(client) -> str:
    return getattr(client, "model", None) or MODEL


def provider_of(client) -> str:
    return "oracle" if client == ORACLE else getattr(client, "provider", "anthropic")


def key_family(key: str) -> str | None:
    """Whose key this is, from the shapes the providers publish: Anthropic's prefix; OpenAI's prefixes or the
    "T3BlbkFJ" every older OpenAI key carries; DeepSeek's "sk-" and 32 hex digits. None when it carries no marker."""
    if key.startswith("sk-ant-"):
        return "anthropic"
    if key.startswith(("sk-proj-", "sk-svcacct-", "sk-admin-", "sk-None-")) or "T3BlbkFJ" in key:
        return "openai"
    if re.fullmatch(r"sk-[0-9a-f]{32}", key):
        return "deepseek"
    return None


def key_var(key: str) -> str:
    """The .env variable a pasted key belongs in, by its shape. A key with no marker is taken as DeepSeek's."""
    return PROVIDERS.get(key_family(key) or "deepseek")[0]


def _create(client, schema, prompt):
    fmt = {"type": "json_schema", "schema": schema}
    try:
        return client.beta.messages.create(
            model=model_of(client), max_tokens=4000,
            betas=["server-side-fallback-2026-07-01"], fallbacks="default",
            output_config={"format": fmt, "effort": effort()},
            messages=[{"role": "user", "content": prompt}],
        )
    except anthropic.BadRequestError:   # betas/fallbacks unsupported -> plain call once
        return client.messages.create(
            model=model_of(client), max_tokens=4000,
            output_config={"format": fmt},
            messages=[{"role": "user", "content": prompt}],
        )


ORACLE = "oracle"       # client sentinel: never call the API; answer from the cache, export misses for humans/agents
EXPORT = None           # path of the jsonl the oracle mode appends misses to (set by grade.py)


def load_answers(cache: Cache, path) -> int:
    """Load {"key": ..., "answer": {...}} lines (one per exported request) into the cache."""
    n = 0
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                row = json.loads(line)
                cache.set(row["key"], row["answer"])
                n += 1
    return n


def _tally(kind: str, schema: dict, prompt: str, res, usage: dict | None) -> None:
    TALLY["calls"] += 1
    if usage and usage.get("prompt_tokens"):
        TALLY["metered"] += 1
    else:   # nothing was metered: weigh what a cold call would send and get back
        usage = {"prompt_tokens": est_tokens(_SYSTEM + json.dumps(schema) + prompt),
                 "completion_tokens": est_tokens(json.dumps(res, ensure_ascii=False), VERDICT_RATE) if res is not None else 0}
    TALLY["tokens_in"] += usage["prompt_tokens"]
    TALLY["tokens_out"] += usage["completion_tokens"]
    TALLY["tokens_reasoning"] += usage.get("reasoning_tokens", 0)
    TALLY["tokens_in_cached"] += usage.get("cached_tokens", 0)
    if f"{kind}_calls" in TALLY:   # the metric is the part of the cache key before the colon
        TALLY[f"{kind}_calls"] += 1
        TALLY[f"{kind}_tokens_in"] += usage["prompt_tokens"]


def ask(client, cache: Cache, schema: dict, prompt: str, key: str) -> dict | None:
    """Cached JSON-schema call. Never raises: refusal, retried BadRequest, parse/connection error -> None.
    Every call lands in TALLY: the API's own token counts when it metered one, an estimate otherwise."""
    ckey = Cache.key("llm", model_of(client), key)
    usage = None
    if client == ORACLE:
        res = cache.get(ckey)
        if res is None and EXPORT:
            with open(EXPORT, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({"key": ckey, "schema": schema, "prompt": prompt}, ensure_ascii=False) + "\n")
        _tally(key.split(":")[0], schema, prompt, res, None)
        return res

    def call():
        nonlocal usage
        try:
            if isinstance(client, Chat):
                res, usage = client.ask(schema, prompt)
                return res
            resp = _create(client, schema, prompt)
        except Exception:
            return None
        u = getattr(resp, "usage", None)
        usage = {"prompt_tokens": getattr(u, "input_tokens", 0) or 0, "completion_tokens": getattr(u, "output_tokens", 0) or 0,
                 "reasoning_tokens": 0, "cached_tokens": getattr(u, "cache_read_input_tokens", 0) or 0}
        if getattr(resp, "stop_reason", None) == "refusal":
            return None
        try:
            for block in resp.content:
                if getattr(block, "type", None) == "text":
                    return json.loads(block.text)
        except Exception:
            return None
        return None

    res = cache.memo(ckey, call)
    _tally(key.split(":")[0], schema, prompt, res, usage)
    return res
