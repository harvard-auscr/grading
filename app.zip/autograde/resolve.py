from __future__ import annotations

import json
import os
import re
import urllib.parse

from autograde import net
from autograde.cache import Cache
from autograde.model import Finding, Metric, Ref, UNWEIGHED

MAILTO = "tech@hauscr.org"
UNVERIFIED_LIST = 5
_TAG = re.compile(r"<[^>]+>")
_TOK = re.compile(r"\w+", re.UNICODE)
_DOI_TAIL = re.compile(r"^ ([0-9a-z]\S{2,})")


def run(refs: list[Ref], cache: Cache, offline: bool = False, scrub=None) -> Metric:
    """scrub masks the text of every search query before it leaves the machine: a reference entry can carry the
    student's own name (a self-citation) or a paragraph glued on after the list (an author's note, a declaration).
    Matching the answers against the entry stays local and uses the entry as written."""
    q = scrub or (lambda s: s)
    if offline:
        return Metric("resolvability", None, status="skipped", rationale="offline")
    if not refs:
        return Metric("resolvability", None, status="not_applicable", rationale="no references")

    findings: list[Finding] = []
    year_mismatch: list[Finding] = []
    unverified: list[Ref] = []
    dead = other = 0
    unchecked = 0

    for ref in refs:
        try:
            outcome = _resolve(ref, cache, findings, year_mismatch, q)
        except (net.NetError, ValueError):   # network/timeout (wrapped) or JSON decode -> entry unchecked
            unchecked += 1
            continue
        if outcome == "dead":
            dead += 1
        elif outcome == "other":
            other += 1
        elif outcome == "unverified":
            unverified.append(ref)

    look = list(year_mismatch)
    for ref in unverified[:UNVERIFIED_LIST]:
        look.append(Finding("resolvability.unverified", 0.0, ref.para, ref.raw, "no index match"))
    if len(unverified) > UNVERIFIED_LIST:
        look.append(Finding("resolvability.unverified", 0.0, None, "", f"+{len(unverified) - UNVERIFIED_LIST} more"))

    bits = []
    if dead:
        bits.append(f"{dead} dead")
    if other:
        bits.append(f"{other} other-work")
    if unverified:
        bits.append(f"{len(unverified)} unverified")
    if year_mismatch:
        bits.append(f"{len(year_mismatch)} year-mismatch")
    if unchecked:
        bits.append(f"{unchecked} unchecked")
    rationale = ", ".join(bits) or "all resolved"
    status = "partial" if unchecked else "ok"
    return Metric("resolvability", None, findings=findings, look=look, rationale=rationale, status=status)


def _doi_status(cache: Cache, doi: str) -> int:
    return cache.memo(Cache.key("doi", doi), lambda: net.status_only("https://doi.org/" + doi))


def _rejoin_doi(ref: Ref) -> str | None:
    """A DOI split by a paragraph join keeps its tail one space away; rejoin it for a second try."""
    at = ref.raw.find(ref.doi)
    if at < 0:
        return None
    tail = _DOI_TAIL.match(ref.raw[at + len(ref.doi):])
    return ref.doi + tail.group(1).rstrip(".,;") if tail else None


def _resolve(ref: Ref, cache: Cache, findings: list[Finding], year_mismatch: list[Finding], q=lambda s: s) -> str:
    """Returns one of: dead | other | resolved | found | unverified. Fills ref.found on 'found'."""
    if ref.doi:
        status = _doi_status(cache, ref.doi)
        if status in (404, 410):
            # the entry wrapped mid-DOI ("10.1016/j.micres 2023.127389") or carries a preprint version suffix (…670328v1)
            retry = [d for d in (_rejoin_doi(ref), re.sub(r"v\d+$", "", ref.doi)) if d and d != ref.doi]
            alive = next((d for d in retry if _doi_status(cache, d) not in (404, 410)), None)
            if alive:
                ref.doi = alive
            else:
                findings.append(Finding("resolvability.doi_dead", UNWEIGHED, ref.para, ref.raw, "DOI does not resolve"))
                return "dead"
        msg = _crossref_work(cache, ref.doi)
        if msg is not None:   # Crossref has the DOI -> registered and known
            ctitle = " ".join(msg.get("title") or [])
            cyear = _cr_year(msg)
            if (ctitle and ref.title and cyear and ref.year and cyear != ref.year
                    and _jaccard(ref.title, ctitle) < 0.4
                    and _containment(ref.title, ctitle) < 0.6):   # "PsyToolkit" inside "PsyToolkit: A novel ..." is the right work
                findings.append(Finding("resolvability.doi_other_work", UNWEIGHED, ref.para, ref.raw,
                                        f"DOI resolves to “{ctitle[:80]}” ({cyear})"))
                return "other"
            # keep metadata so tiers 4-5 can verify DOI-bearing references too; Crossref already vouched for the DOI,
            # so an OpenAlex outage or spent budget only costs the abstract, never the entry
            try:
                oa = _openalex_doi(ref.doi, cache)
            except net.NetError:
                oa = None
            found = oa or {
                "source": "crossref", "id": ref.doi, "title": ctitle, "year": cyear,
                "abstract": _TAG.sub("", msg.get("abstract", "")), "oa_url": ""}
            if ref.title and found.get("title") and _jaccard(ref.title, found["title"]) < 0.4 and _containment(ref.title, found["title"]) < 0.6:
                found["abstract"] = ""   # the DOI may point elsewhere; never pair its abstract with the entry's own title
            ref.found = found
            return "resolved"
        # DOI registered but Crossref miss -> fall through to search to populate metadata

    if _search(ref, cache, year_mismatch, q):
        return "found"
    return "unverified"


def _search(ref: Ref, cache: Cache, year_mismatch: list[Finding], q=lambda s: s) -> bool:
    try:
        found = _openalex(ref, cache, q)
    except net.NetError:   # OpenAlex down or out of budget: Crossref decides; a Crossref miss stays unchecked, not unverified
        found = _crossref_search(ref, cache, q)
        if not found:
            raise
    else:
        found = found or _crossref_search(ref, cache, q)
    if not found:
        return False
    ref.found = found
    fyear = found.get("year")
    if fyear and ref.year and abs(fyear - ref.year) > 1:
        year_mismatch.append(Finding("resolvability.year_mismatch", 0.0, ref.para, ref.raw,
                                     f"listed {ref.year}, found {fyear}"))
    return True


def _openalex(ref: Ref, cache: Cache, q=lambda s: s) -> dict | None:
    if len(_TOK.findall(ref.title)) < 4:   # a short or garbled title matches anything
        return None
    title = q(ref.title)
    url = "https://api.openalex.org/works?" + urllib.parse.urlencode(
        {"search": title, "per-page": 3, "mailto": MAILTO, **_oa_key()})
    data = cache.memo(Cache.key("openalex", title), lambda: _json(url))
    for w in (data or {}).get("results", []):
        title = w.get("title") or w.get("display_name") or ""
        if title and _jaccard(ref.title, title) >= 0.75:
            return _oa(w)
    return None


def _openalex_doi(doi: str, cache: Cache) -> dict | None:
    url = "https://api.openalex.org/works/https://doi.org/" + urllib.parse.quote(doi, safe="/") + "?" + urllib.parse.urlencode(
        {"mailto": MAILTO, **_oa_key()})
    w = cache.memo(Cache.key("openalex", "doi", doi), lambda: _json(url))
    return _oa(w) if w and w.get("id") else None


def _oa_key() -> dict:
    """OPENALEX_API_KEY (.env): without one, every request spends a small free daily budget shared by the whole IP."""
    key = (os.environ.get("OPENALEX_API_KEY") or "").strip()
    return {"api_key": key} if key else {}


def _oa(w: dict) -> dict:
    oa = w.get("best_oa_location") or {}
    return {"source": "openalex", "id": w.get("id", ""), "title": w.get("title") or w.get("display_name") or "",
            "year": w.get("publication_year"), "abstract": _rebuild(w.get("abstract_inverted_index")),
            "oa_url": oa.get("url") or oa.get("pdf_url") or ""}


def _crossref_search(ref: Ref, cache: Cache, q=lambda s: s) -> dict | None:
    query = q(ref.raw or ref.title)
    if not query or len(_TOK.findall(ref.title)) < 4:
        return None
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode(
        {"query.bibliographic": query, "rows": 3, "mailto": MAILTO})
    data = cache.memo(Cache.key("crossref", "search", query), lambda: _json(url))
    for w in ((data or {}).get("message") or {}).get("items", []):
        title = " ".join(w.get("title") or [])
        if title and ref.title and _jaccard(ref.title, title) >= 0.75:
            return {
                "source": "crossref",
                "id": w.get("DOI", ""),
                "title": title,
                "year": _cr_year(w),
                "abstract": _TAG.sub("", w.get("abstract", "")),
                "oa_url": "",
            }
    return None


def _crossref_work(cache: Cache, doi: str) -> dict | None:
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi, safe="") + "?mailto=" + MAILTO
    data = cache.memo(Cache.key("crossref", doi), lambda: _json(url))
    if not data:
        return None
    return data.get("message")


def _json(url: str) -> dict:
    """Fetch JSON; a non-200 is a miss ({}), a 200 with bad JSON raises (entry unchecked)."""
    status, _ctype, body = net.get(url)
    if status == 429 or status >= 500:
        raise net.NetError(f"http {status}")   # transient: leave the entry unchecked, never memoize the failure
    if status != 200:
        return {}
    return json.loads(body)   # ValueError on bad JSON -> unchecked


def _cr_year(work: dict):
    for field in ("issued", "published", "published-online", "published-print"):
        parts = (work.get(field) or {}).get("date-parts") or []
        if parts and parts[0] and parts[0][0]:
            return parts[0][0]
    return None


def _rebuild(inv: dict | None) -> str:
    if not inv:
        return ""
    positions = sorted((i, word) for word, idxs in inv.items() for i in idxs)
    return " ".join(word for _i, word in positions)


def _containment(a: str, b: str) -> float:
    sa, sb = set(_TOK.findall(a.lower())), set(_TOK.findall(b.lower()))
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / min(len(sa), len(sb))


def _jaccard(a: str, b: str) -> float:
    sa, sb = set(_TOK.findall(a.lower())), set(_TOK.findall(b.lower()))
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)
