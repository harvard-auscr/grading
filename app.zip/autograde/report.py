from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path

from autograde.model import METRICS

QUOTE_MAX = 160   # characters of a finding's quote in the report, cut after masking


def _fmt(score) -> str:
    return "—" if score is None else f"{score:.1f}"


def _pnum(para) -> str:
    return "doc" if para is None else str(para)


def write_paper(out: Path, meta: dict, doc, metrics: dict, overall: dict,
                look: list, red, run: dict) -> dict:
    """Write <paper_id>.json and <paper_id>.md; every quote/note passes through red.scrub. Return the JSON dict."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    scrub = red.scrub
    dropped = getattr(red, "dropped", set())

    def fdict(f) -> dict:   # mask first, then cut: a name cut in half by the limit would no longer match
        quote = "" if f.para in dropped else scrub(f.quote)[:QUOTE_MAX]
        return {"code": f.code, "weight": f.weight, "para": f.para, "quote": quote, "note": scrub(f.note)}

    mjson: dict[str, dict] = {}
    comments: list[dict] = []
    for name in METRICS:
        m = metrics.get(name)
        if m is None:
            continue
        findings = [fdict(f) for f in m.findings]
        mjson[name] = {
            "name": m.name, "score": m.score, "status": m.status,
            "rationale": m.rationale,
            "findings": findings,
            "look": [fdict(f) for f in m.look],
        }
        comments += [{"para": f["para"], "quote": f["quote"], "note": f["note"]} for f in findings]

    removed = sum(red.report.values())
    data = {
        "schema_version": 1,
        "paper_id": meta.get("paper_id", ""),
        "program": meta.get("program", ""),
        "edition": meta.get("edition", ""),
        "round": meta.get("round", ""),
        "source": meta.get("source", ""),
        "words": getattr(doc, "words", 0),
        "metrics": mjson,
        "overall": overall,
        "redaction": {"removed": removed, "kinds": dict(sorted(red.report.items()))},
        "comments": comments,
        "look": [fdict(f) for f in look],
        "run": run,
    }

    pid = data["paper_id"]
    (out / f"{pid}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / f"{pid}.md").write_text(_md(data), encoding="utf-8")
    return data


def _md(data: dict) -> str:
    L = [f"# {data['paper_id']}", "", f"words: {data['words']} · overall: {_fmt(data['overall'].get('score'))}"
         + ("  (partial)" if data["overall"].get("partial") else ""), "",
         "| metric | score | rationale |", "| --- | --- | --- |"]
    for name in METRICS:
        m = data["metrics"].get(name)
        if m is None:
            continue
        L.append(f"| {name} | {_fmt(m['score'])} | {m['rationale']} |")
    L += ["", "## Comments"]
    if data["comments"]:
        for c in data["comments"]:
            L.append(f'¶{_pnum(c["para"])} "{c["quote"]}" — {c["note"]}')
    else:
        L.append("_none_")
    L += ["", "## Needs a look"]
    if data["look"]:
        for f in data["look"]:
            L.append(f'¶{_pnum(f["para"])} "{f["quote"]}" — {f["note"]}')
    else:
        L.append("_none_")
    run = data["run"]
    L += ["", "_run: " + " ".join(f"{k}={run[k]}" for k in sorted(run)) + "_", ""]
    return "\n".join(L)


SUMMARY_COLS = ["paper_id", "round", "sheet_row", "words", *METRICS,
                "overall", "partial", "top_codes", "status"]
# usage.csv: the paper, then what its LLM checks weighed, then who served them, then the run.
USAGE_COLS = ["paper_id", "round", "role", "words", "references", "status",
              "llm_calls", "llm_metered", "llm_tokens_in", "llm_tokens_out", "llm_tokens_reasoning", "llm_tokens_in_cached",
              "llm_relevancy_calls", "llm_relevancy_tokens_in", "llm_numbers_calls", "llm_numbers_tokens_in",
              "provider", "model", "cache_hits", "seconds"]


def write_prompts(out: Path, provider: str, model: str) -> Path:
    """llm-prompts.md: what the two LLM checks send and the JSON they must return, for this run's record."""
    from . import llm, numbers, relevancy
    L = ["# LLM checks: prompts and output shapes", "", f"provider: {provider} · model: {model}", "",
         "## System instruction", "",
         "Sent on the DeepSeek route, followed by the check's JSON schema. OpenAI and Anthropic get the same",
         "schema through the API's structured-output setting instead. Every reply is checked against it.", "",
         "```", llm._SYSTEM.strip(), "```"]
    for name, mod, note in (
            ("Relevancy", relevancy, f"One request per {relevancy.BATCH} citing sentences, one block per item. The abstract line "
                                     "is left out when the source has none and cut at 600 characters."),
            ("Numbers", numbers, "One request per cited numeric claim whose source text the grader fetched and matched to the "
                                 f"reference. The source is cut at {numbers.SOURCE_TRUNC:,} characters.")):
        L += ["", f"## {name}", "", note, "", "### Prompt template", "", "```", mod.TEMPLATE, "```", "",
              "### Output shape (JSON schema)", "", "```json", json.dumps(mod.SCHEMA, indent=2), "```", "",
              "### Example output", "", "```json", json.dumps(mod.EXAMPLE, indent=2), "```"]
    path = Path(out) / "llm-prompts.md"
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
    return path


def write_usage(out: Path, results: list[dict]) -> Path:
    """One row per paper for pricing a round. llm_metered counts the calls an API counted itself;
    the rest are estimates of what a cold call would send and receive."""
    path = Path(out) / "usage.csv"
    with path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=USAGE_COLS, extrasaction="ignore")
        w.writeheader()
        for r in sorted(results, key=lambda x: str(x.get("paper_id", ""))):
            w.writerow({**r.get("run", {}), **{k: r.get(k, "") for k in USAGE_COLS[:6]}})
    return path


def write_summary(out: Path, results: list[dict]) -> Path:
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "summary.csv"
    with path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=SUMMARY_COLS)
        w.writeheader()
        for r in sorted(results, key=lambda x: str(x.get("paper_id", ""))):
            w.writerow(_summary_row(r))
    return path


def _summary_row(r: dict) -> dict:
    metrics = r.get("metrics", {})
    codes = Counter(f["code"] for m in metrics.values() for f in m.get("findings", []))
    top = [c for c, _ in sorted(codes.items(), key=lambda kv: (-kv[1], kv[0]))[:3]]
    row = {
        "paper_id": r.get("paper_id", ""),
        "round": r.get("round", ""),
        "sheet_row": r.get("sheet_row", ""),
        "words": r.get("words", ""),
        "overall": (r.get("overall") or {}).get("score", ""),
        "partial": (r.get("overall") or {}).get("partial", ""),
        "top_codes": ";".join(top),
        "status": r.get("status", "ok"),
    }
    for name in METRICS:
        m = metrics.get(name)
        row[name] = "" if not m or m.get("score") is None else m["score"]
    return row
