from __future__ import annotations

import re

# Priority order matters: "Results and Discussion" -> results, "Introduction and Background" -> background|introduction both satisfy.
SYNONYMS: list[tuple[str, str]] = [
    ("references", r"references?|reference list|bibliography|works cited|参考文献"),
    ("appendix", r"appendix|appendices|supplementary( materials?)?|附录"),
    ("acknowledgments", r"acknowledge?ments?|致谢"),
    ("abstract", r"abstract|摘要"),
    ("keywords", r"key ?words?|关键词"),
    ("conclusion", r"conclusions?|concluding remarks|summary and outlook|结论"),
    ("results", r"results?|findings|analysis|experiments?|evaluation|verification|结果"),
    ("discussion", r"discussion|limitations?|讨论"),
    ("methods", r"methods?|methodology|materials? and methods?|research design|experimental (design|setup)|data (collection|and methods?)|方法"),
    ("background", r"background|literature review|related work|prior work|previous (research|studies)|theoretical (basis|framework|foundation)s?|essential research|文献综述|研究背景"),
    ("introduction", r"introduction|overview|引言|绪论"),
]
STOP = ("references", "appendix", "acknowledgments")
_active: list[tuple[str, str]] = list(SYNONYMS)   # SYNONYMS plus the running rubric's [sections]


def names() -> list[str]:
    """The built-in section names a rubric can require."""
    return [n for n, _ in SYNONYMS]


def use_sections(extra: dict[str, str]) -> None:
    """Take a rubric's [sections]: a new name is looked for first (so "literature_review" can be its own section
    rather than background), and a built-in name gets the extra headings as more ways to write it."""
    global _active
    extra = dict(extra or {})
    new = [(n, pat) for n, pat in extra.items() if n not in dict(SYNONYMS)]
    _active = new + [(n, f"{pat}|{extra[n]}" if n in extra else pat) for n, pat in SYNONYMS]

_FIELD = re.compile(r"^(?:PAGE\s*)?(?:[IVXLC]+|\d+)(?=[A-Z一-鿿])")   # field residue glued on: "PAGE IIAbstract", "1Introduction"
# "2.1 ", "7.Reference", "iii) ". Every token must end in a separator or touch the heading word, so a digit run cannot
# be split many ways: the old `\d+[.)]?\s*` took minutes on an 18-digit paragraph.
_NUM = re.compile(r"^(?:\d+(?:\.\d+)*(?:[.)](?:\s+|(?=[a-z一-鿿]))|\s+|(?=[a-z一-鿿]))|[ivx]+(?:[.)]\s*|\s+)"
                  r"|[a-hj-uwyz][.)]\s*)+(?=[a-z一-鿿])")
_TRAIL = re.compile(r"(\s*[:：]|\s*\([^)]*\))\s*$")


def clean(text: str) -> str:
    t = _FIELD.sub("", text.strip()).lower()
    t = _NUM.sub("", t).rstrip()
    t = t[:-200] + _TRAIL.sub("", t[-200:])   # only the tail: on a long run of spaces the full match is quadratic
    return re.sub(r"\s+", " ", t).strip()


def canon(text: str, synonyms=None, max_words: int = 8) -> str | None:
    synonyms = _active if synonyms is None else synonyms
    t = clean(text)
    if not t or len(t.split()) > max_words or "://" in t:   # a section heading never carries a URL
        return None
    # A buried synonym ("The Tetrahedral Reference") is not a section; only very short lines may match mid-line.
    seek = re.search if len(t.split()) <= 3 else re.match
    for cand in (t, re.split(r"[:：]", t, maxsplit=1)[0].strip()):
        for name, pat in synonyms:
            if seek(rf"(?:^|\b)(?:{pat})(?:\b|$)", cand):
                return name
    return None


def inline(text: str, name: str, synonyms=None) -> bool:
    """Fallback for unstyled 'Abstract: ...' / 'Keywords：...' / 'References' first-line forms."""
    head = re.split(r"[:：]", text.strip(), maxsplit=1)[0]
    return len(head.split()) <= 3 and canon(head, synonyms) == name
