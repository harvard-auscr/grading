from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from pathlib import Path


class Cache:
    """Content-keyed kv store so lookups and LLM verdicts are replayed, never repeated."""

    def __init__(self, path: Path | str = ".cache/lookups.sqlite"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(path))
        self.db.execute("create table if not exists kv (key text primary key, value text, ts real)")
        self.hits = 0

    @staticmethod
    def key(kind: str, *parts: str) -> str:
        return hashlib.sha256((kind + "\x1f" + "\x1f".join(parts)).encode("utf-8")).hexdigest()

    def get(self, key: str):
        row = self.db.execute("select value from kv where key = ?", (key,)).fetchone()
        if row:
            self.hits += 1
            return json.loads(row[0])
        return None

    def set(self, key: str, value) -> None:
        self.db.execute("insert or replace into kv values (?, ?, ?)", (key, json.dumps(value, ensure_ascii=False, sort_keys=True), time.time()))
        self.db.commit()

    def memo(self, key: str, fn):
        v = self.get(key)
        if v is None:
            v = fn()
            if v is not None:
                self.set(key, v)
        return v
