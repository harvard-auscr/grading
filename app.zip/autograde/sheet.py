from __future__ import annotations

import csv
import io
from pathlib import Path

# field -> keyword candidates (case-insensitive substring), first header match wins.
COLS: dict[str, tuple[str, ...]] = {
    "title": ("Paper Title", "Project Title", "Research Title", "Essay Title", "论文题目", "题目", "Title"),
    "discipline": ("Discipline",),
    "cn_name": ("CN Name",),
    "en_name": ("EN Name",),
    "school": ("School EN", "School", "学校"),
    "mentor": ("Mentor", "导师"),
    "email": ("邮箱", "Email"),
    "writing_structure": ("Writing Structure",),
    "background": ("Research Background",),
    "methods": ("Research Methods",),
    "conclusion": ("Conclusion",),
    "journal": ("journal quality",),
}


def _records(path: Path | str) -> list[list[str]]:
    text = Path(path).read_text(encoding="utf-8-sig")
    # csv over the whole text, not splitlines(): a line break inside a quoted cell stays in the cell, and an unquoted
    # U+2028 in a title cannot split a row and shift every later sheet_row (tools/ingest_papers.read_sheet agrees).
    return list(csv.reader(io.StringIO(text, newline="")))


def _col_map(header: list[str]) -> dict[str, int]:
    low = [c.lower() for c in header]
    out: dict[str, int] = {}
    for field, needles in COLS.items():
        for needle in needles:
            n = needle.lower()
            j = next((k for k, c in enumerate(low) if n in c), None)
            if j is not None:
                out[field] = j
                break
    return out


# The header row as tools/ingest_papers.header_row finds it (tests/test_sheet.py keeps the two in step).
_TITLES = ("paper title", "project title", "research title", "essay title", "论文题目", "题目", "title")
_WORDS = (*_TITLES, "paper folder", "file name", "team id", "en name", "cn name", "school", "mentor",
          "discipline", "email", "link", "folder", "文件名", "姓名", "学校", "导师", "邮箱")


def _names_column(cell: str, words) -> bool:
    c = cell.strip().lower()
    return any(c == w or (c.startswith(w) and not c[len(w)].isalnum()) for w in words)


def header_row(rows: list[list[str]]) -> int:
    best, most = None, 0
    for i, r in enumerate(rows):
        if any(_names_column(c, _TITLES) for c in r):
            n = sum(_names_column(c, _WORDS) for c in r)
            if n > most:
                best, most = i, n
    if best is None:
        raise StopIteration
    return best


def load(path: Path | str) -> dict[int, dict]:
    """sheet_row (1-based csv.reader index) -> row of the keyword columns; same indexing as tools/ingest_papers.py."""
    rows = _records(path)
    hi = header_row(rows)
    cmap = _col_map(rows[hi])
    out: dict[int, dict] = {}
    for i, r in enumerate(rows):
        if i <= hi:
            continue
        out[i + 1] = {f: (r[cmap[f]].strip() if f in cmap and cmap[f] < len(r) else "") for f in COLS}
    return out


def row_for(row: dict, sheets: dict) -> dict | None:
    """Sheet row behind a manifest/result row, or None when round/sheet_row is missing or non-numeric."""
    rd, sr = str(row.get("round", "")), str(row.get("sheet_row", ""))
    if not rd.isdigit() or not sr.strip().isdigit():
        return None
    return sheets.get(int(rd), {}).get(int(sr))


def round_rows(row: dict, sheets: dict) -> list[dict]:
    """Every other sheet row of this paper's round: the classmates whose names redaction also masks."""
    rd, sr = str(row.get("round", "")), str(row.get("sheet_row", "")).strip()
    if not rd.isdigit():
        return []
    return [r for n, r in sheets.get(int(rd), {}).items() if str(n) != sr]


def manifest(path: Path | str) -> list[dict]:
    with open(path, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))
