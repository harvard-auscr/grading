"""A program's rubric: rubric/<program>.toml, the one place a program's grading is set (which checks run and what
they weigh, what each finding deducts, the sections a paper needs). load() checks the whole file before any paper is
graded, so a mistake in it stops the round with a plain sentence instead of failing paper by paper."""
from __future__ import annotations

import re
import tomllib
from pathlib import Path

from autograde import headings
from autograde.model import DEDUCTIONS, LOOKS, METRICS, Metric

DIR = Path(__file__).resolve().parents[1] / "rubric"


class RubricError(ValueError):
    """The rubric file is missing or wrong; the message says what to change."""


def available(root: Path = DIR) -> list[str]:
    """The programs that have a rubric, e.g. ["ysa"]."""
    return sorted(p.stem for p in Path(root).glob("*.toml") if re.fullmatch(r"[a-z]+", p.stem))


def path_for(program: str, root: Path = DIR) -> Path:
    path = Path(root) / f"{program}.toml"
    if not re.fullmatch(r"[a-z]+", program or "") or not path.is_file():
        have = ", ".join(available(root)) or "none"
        raise RubricError(f"There is no rubric for the program {program!r} (add rubric/{program}.toml; "
                          f"rubrics now: {have}).")
    return path


def load(path: Path | str) -> dict:
    path = Path(path)
    try:
        r = tomllib.loads(path.read_bytes().decode("utf-8-sig"))   # "UTF-8 with BOM" (Windows Notepad) is UTF-8 too
    except FileNotFoundError:
        raise RubricError(f"{path.name}: no such rubric file.") from None
    except tomllib.TOMLDecodeError as e:
        raise RubricError(f"{path.name} is not valid TOML: {e}") from None
    except UnicodeDecodeError:
        raise RubricError(f"{path.name} is not a UTF-8 text file; save it as UTF-8.") from None
    return validate(r, path.name)


def _number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0


def validate(r: dict, name: str = "the rubric") -> dict:
    """Check a parsed rubric and fill its defaults. Every problem is listed at once."""
    errs: list[str] = []
    if r.get("schema") != 1:
        errs.append("schema must be 1")
    r.setdefault("look_cap", 5)
    r.setdefault("count_cap", 4)
    for key, lo in (("look_cap", 0), ("count_cap", 1)):
        if not (isinstance(r[key], int) and not isinstance(r[key], bool) and r[key] >= lo):
            errs.append(f"{key} must be a whole number of at least {lo}")

    metrics = r.get("metrics")
    if not isinstance(metrics, dict) or not metrics:
        errs.append("[metrics] must list at least one check and its weight, e.g. citations = 4")
        metrics = {}
    for m, w in metrics.items():
        if m not in METRICS:
            errs.append(f"[metrics] {m!r} is not a check; the checks are {', '.join(METRICS)}")
        elif not _number(w):
            errs.append(f"[metrics] {m} must be a number of 0 or more")

    weights = r.get("weights", {})
    if not isinstance(weights, dict):
        errs.append("[weights] must be a table")
        weights = {}
    for code, w in weights.items():
        metric, _, short = code.partition(".")
        if short in LOOKS.get(metric, ()) and short not in DEDUCTIONS.get(metric, ()):
            errs.append(f"[weights] {code} only asks for a look and never deducts; remove its weight")
        elif short not in DEDUCTIONS.get(metric, ()):
            known = ", ".join(f"{metric}.{c}" for c in DEDUCTIONS.get(metric, ())) or "none"
            errs.append(f"[weights] {code!r} is not a finding code (for {metric}: {known})")
        elif metric not in metrics:
            errs.append(f"[weights] {code}: this rubric does not run {metric} (add it to [metrics] or drop the weight)")
        elif not _number(w):
            errs.append(f"[weights] {code} must be a number of 0 or more")
    for metric in metrics:
        missing = [f"{metric}.{c}" for c in DEDUCTIONS.get(metric, ()) if f"{metric}.{c}" not in weights]
        if missing:
            errs.append(f"[weights] has no weight for {', '.join(missing)}")

    sections = r.get("sections", {})
    if not isinstance(sections, dict):
        errs.append("[sections] must be a table of section name = heading words")
        sections = {}
    for sec, pat in sections.items():
        if not re.fullmatch(r"[a-z][a-z_]*", sec):
            errs.append(f"[sections] {sec!r}: a section name is lower-case letters and _")
        try:
            re.compile(pat)
        except (re.error, TypeError):
            errs.append(f"[sections] {sec}: {pat!r} is not a valid pattern")

    if "structure" in metrics:
        st = r.get("structure")
        if not isinstance(st, dict):
            errs.append("[structure] is needed when the rubric runs structure")
        else:
            known = set(headings.names()) | set(sections)
            for key in ("required", "expected"):
                items = st.setdefault(key, [])
                if not (isinstance(items, list) and all(isinstance(x, str) for x in items)):
                    errs.append(f"[structure] {key} must be a list of section names")
                    continue
                for alt in (a for x in items for a in x.split("|")):
                    if alt not in known:
                        errs.append(f"[structure] {key}: {alt!r} is not a section name (known: "
                                    f"{', '.join(sorted(known))}; add new ones under [sections])")
            aw = st.get("abstract_words")
            if not (isinstance(aw, list) and len(aw) == 2 and all(isinstance(x, int) for x in aw) and 0 < aw[0] < aw[1]):
                errs.append("[structure] abstract_words must be [shortest, longest], e.g. [80, 400]")
    if errs:
        raise RubricError(f"{name}: " + "; ".join(errs) + ".")
    return r


def use(r: dict) -> None:
    """Apply what the rubric changes outside scoring: its extra section names, for every heading lookup."""
    headings.use_sections(r.get("sections", {}))


def score(m: Metric, rubric: dict) -> Metric:
    """Set m.score. Deductions come only from the rubric weights (KeyError on an unweighted code)."""
    if m.status in ("not_applicable", "skipped"):
        m.score = None
        return m
    weights, cap = rubric["weights"], rubric.get("count_cap", 4)
    seen: dict[str, int] = {}
    total = 0.0
    for f in m.findings:
        f.weight = weights[f.code]          # raise on a finding code with no weight
        seen[f.code] = seen.get(f.code, 0) + 1
        if seen[f.code] <= cap:             # one habit repeated 14 times is not 14 separate faults
            total += f.weight
    m.score = round(max(1.0, 10 - total), 1)
    return m


def overall(metrics: dict[str, Metric], rubric: dict) -> dict:
    mw = rubric["metrics"]
    num = den = 0.0
    used: dict[str, float] = {}
    excluded: list[str] = []
    for name in sorted(metrics):
        if name not in METRICS:
            raise ValueError(f"unknown metric {name!r}")
        m = metrics[name]
        if m.score is None:
            excluded.append(name)
            continue
        w = mw[name]
        num += w * m.score
        den += w
        used[name] = w
    return {
        "score": round(num / den, 1) if den else None,
        "partial": any(m.status == "partial" for m in metrics.values()),
        "weights": used,
        "excluded": sorted(excluded),
    }


def cap_look(metrics: dict[str, Metric], rubric: dict) -> tuple[list, int]:
    """First look_cap look items in metric order then finding order, plus the dropped count."""
    cap = rubric["look_cap"]
    items: list = []
    for name in METRICS:
        m = metrics.get(name)
        if m:
            items.extend(m.look)
    return items[:cap], max(0, len(items) - cap)
