from __future__ import annotations

import hashlib

from .model import Finding, Marker, Metric, Ref, UNWEIGHED
from .redact import Redactor

MAX_SENTENCES = 2
BATCH = 25
_VERDICTS = ("supports", "off_topic", "cannot_tell")
SCHEMA = {
    "type": "object",
    "properties": {
        "items": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "i": {"type": "integer"},
                    "verdict": {"type": "string", "enum": list(_VERDICTS)},
                    "why": {"type": "string"},
                },
                "required": ["i", "verdict", "why"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["items"],
    "additionalProperties": False,
}
# The off_topic definition is calibrated against human calls (tools/calibrate_relevancy.py, 2026-09-21):
# a source on the same subject is supports even when it does not address the exact point.
_TASK = ("For each item, judge whether the cited source could support the claim it is cited for. "
         "A sentence may cite several works; judge only the part attributed to the source named in 'Cited as'. "
         "verdict: supports (the source is on the same subject and could plausibly back the claim, even if it does not "
         "address this exact point or wording) | off_topic (the source has nothing to do with anything in the sentence; "
         "being narrower, broader, or a different angle on the same subject is not off_topic) | cannot_tell (title/abstract "
         "too thin to say). When in doubt between supports and off_topic, choose supports. Keep 'why' to <= 12 words.")
# The shape _prompt builds, for llm-prompts.md: one block per item, the abstract line only when there is one.
TEMPLATE = _TASK + "\n[{i}] Source title: {title}\nSource abstract: {abstract}\nCited as: {key}\nCiting sentence: {sentence}\n"
EXAMPLE = {"items": [{"i": 0, "verdict": "supports", "why": "same topic, plausibly backs the claim"}]}


def _pairs(red: Redactor, refs: list[Ref], markers: list[Marker]) -> list[dict]:
    pairs: list[dict] = []
    skip = getattr(red, "dropped", set())   # acknowledgments and front matter never reach the LLM
    for ref in sorted(refs, key=lambda r: r.i):
        if not ref.found or not ref.title:
            continue
        bound, seen = [], set()
        for m in sorted((m for m in markers if m.entries == [ref.i] and m.para not in skip),
                        key=lambda m: (m.para, m.text)):
            if m.text not in seen:   # one sentence, one pair, however many times it cites the entry
                seen.add(m.text)
                bound.append(m)
        for m in bound[:MAX_SENTENCES]:
            pairs.append({"ref": ref, "marker": m, "sentence": red.scrub(m.text)})
    return pairs


def _prompt(red: Redactor, batch: list[tuple[int, dict]]) -> str:
    lines = [_TASK]
    for idx, p in batch:
        ref = p["ref"]
        abstract = red.scrub((ref.found or {}).get("abstract") or "")
        lines.append(f"[{idx}] Source title: {red.scrub(ref.title)}")
        if abstract:
            lines.append(f"Source abstract: {abstract[:600]}")
        lines.append(f"Cited as: {red.scrub_key(p['marker'].key)}")   # "surname:year": a self-citation names the student
        lines.append(f"Citing sentence: {p['sentence']}\n")
    return "\n".join(lines)


def run(red: Redactor, refs: list[Ref], markers: list[Marker], ask) -> Metric:
    pairs = _pairs(red, refs, markers)
    if not pairs:
        return Metric("relevancy", None, status="not_applicable", rationale="no resolved citing sentences")

    indexed = list(enumerate(pairs))
    findings: list[Finding] = []
    status = "ok"
    checked = 0
    for start in range(0, len(indexed), BATCH):
        batch = indexed[start:start + BATCH]
        prompt = _prompt(red, batch)
        key = "relevancy:" + hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        res = ask(SCHEMA, prompt, key)
        if res is None:
            status = "partial"
            continue
        checked += len(batch)
        by_idx = {idx: p for idx, p in batch}
        for item in res.get("items", []):
            if item.get("verdict") != "off_topic":
                continue
            p = by_idx.get(item.get("i"))
            if p is None:
                continue
            m = p["marker"]
            findings.append(Finding("relevancy.off_topic", UNWEIGHED, m.para, p["sentence"],
                                    (item.get("why") or "")[:120]))

    findings.sort(key=lambda f: (f.para if f.para is not None else -1, f.quote))
    if checked < len(pairs):   # a skipped batch was never judged; never claim it was
        status = "partial"
    return Metric("relevancy", None, findings=findings, status=status,
                  rationale=f"{len(findings)} off-topic of {checked} checked")
