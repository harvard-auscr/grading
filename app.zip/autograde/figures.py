from __future__ import annotations

import re

from autograde.model import Finding, Metric, UNWEIGHED

# A finite verb right after the label means the sentence talks about the figure, not captions it.
FINITE = {"shows", "presents", "illustrates", "depicts", "summarizes", "reports",
          "displays", "demonstrates", "indicates", "lists", "compares", "describes"}

_TOKEN = re.compile(r"(?<![A-Za-z])(fig\.?|figure\.?|table\.?|chart|图|表)\s*#?\s*(\d+(?:[-.]\d+)?)", re.I)   # "Table #2", "Figure.9."
# "Figures 2 and 3", "Table 1 to Table 5", "Figs. 6, 7", "Tables 1-3": the numbers after the first one
_SEP = r"(,\s*(?:and|&|or)|,|，|、|and|&|or|to|through|–|—|-|~)"
_LIST = re.compile(r"(?<![A-Za-z])(figs?\.?|figures?|tables?|charts?|图|表)\s*(\d+)"
                   r"((?:\s*" + _SEP + r"\s*(?:(?:figs?\.?|figures?|tables?|charts?)\s*)?\d+(?!\.?\d))+)", re.I)
_LIST_ITEM = re.compile(_SEP + r"\s*(?:(figs?\.?|figures?|tables?|charts?)\s*)?(\d+)", re.I)
_RANGE = {"to", "through", "–", "—", "-", "~"}
_SUPP = re.compile(r"supplement(?:ary|al)\s*$", re.I)
_NEXTWORD = re.compile(r"[A-Za-z一-鿿]+")
_CAPPUNCT = re.compile(r"\s*[.:：\t|\-—]")


def _type(word: str) -> str:
    w = word.lower().rstrip(".")
    if w in ("table", "表"):
        return "table"
    return "figure"   # fig / figure / chart / 图


def _caption(text: str):
    """(type, label) when the paragraph opens with a caption label; None if it is a mention."""
    m = _TOKEN.match(text)
    if not m:
        return None
    tail = text[m.end():]
    if _CAPPUNCT.match(tail):   # "Figure 4: ..." is a caption at any length
        return _type(m.group(1)), m.group(2)
    if len(text.split()) > 25:
        return None
    nxt = _NEXTWORD.match(tail.lstrip(" .:：)-—、|\t"))
    if nxt and (nxt.group(0)[:1].islower() or nxt.group(0).lower() in FINITE):
        return None   # running text: "Figure 1 gives the overall architecture ..."
    return _type(m.group(1)), m.group(2)


def _listed(text: str) -> set[tuple[str, str]]:
    """Labels named after the first one in a list or range mention; they only ever satisfy a caption."""
    out: set[tuple[str, str]] = set()
    for m in _LIST.finditer(text):
        typ, prev = _type(m.group(1).rstrip("s.") or m.group(1)), int(m.group(2))
        out.add((typ, str(prev)))                  # "Figures 1, 2": a plural first label is no _TOKEN mention
        for sep, word, num in _LIST_ITEM.findall(m.group(3)):
            n = int(num)
            if word and _type(word.rstrip("s.") or word) != typ:   # "Table 2 and Figures 3-4": a new type
                typ, prev = _type(word.rstrip("s.") or word), n
                out.add((typ, str(n)))
                continue
            if sep.lower().strip(", ") in _RANGE:
                if prev < n <= prev + 30:          # "3-1" is a chapter number, not a range: add nothing
                    out.update((typ, str(k)) for k in range(prev, n + 1))
            elif n <= 200:
                out.add((typ, str(n)))
            prev = n
    return out


def _gap(labels: list[str]) -> str | None:
    """Missing numbers within a scheme: plain 1,2,3 or hierarchical N-M compared within chapter N."""
    plain: list[int] = []
    hier: dict[str, list[int]] = {}
    for lab in labels:
        parts = re.split(r"[-.]", lab, maxsplit=1)
        if len(parts) == 1:
            plain.append(int(parts[0]))
        else:
            hier.setdefault(parts[0], []).append(int(parts[1]))
    missing: list[str] = []
    s = sorted(set(plain))
    if s:
        missing += [str(n) for n in range(s[0], s[-1] + 1) if n not in set(s) and str(n) not in hier]   # 4 exists as 4.1/4.2
    for ch in sorted(hier):
        sub = sorted(set(hier[ch]))
        missing += [f"{ch}-{n}" for n in range(sub[0], sub[-1] + 1) if n not in set(sub)]
    return ("missing " + ", ".join(missing)) if missing else None


def run(doc) -> Metric:
    captions: list[tuple[str, str, int]] = []          # (type, label, para anchor)
    cap_labels: dict[str, set[str]] = {}
    mentions: set[tuple[str, str]] = set()
    mention_para: dict[tuple[str, str], int] = {}
    mention_text: dict[tuple[str, str], str] = {}
    listed: set[tuple[str, str]] = set()

    # text boxes are flattened into their host paragraph, so every line starts a possible caption; table cells too
    units = [(line.strip(), p.i) for p in doc.paras for line in p.text.split("\n")]
    units += [(cell.strip(), None) for tbl in doc.tables for cell in tbl]
    for t, anchor in units:
        if not t:
            continue
        start = 0
        cap = _caption(t)
        if cap:
            typ, label = cap
            captions.append((typ, label, anchor))
            cap_labels.setdefault(typ, set()).add(label)
            start = _TOKEN.match(t).end()   # skip the caption's own label when harvesting mentions
        listed |= _listed(t[start:])
        for m in _TOKEN.finditer(t, start):
            if _SUPP.search(t[max(0, m.start() - 16):m.start()]):
                continue   # "Supplementary Figure 5" lives outside the paper; it needs no caption here
            key = (_type(m.group(1)), m.group(2))
            if cap and _CAPPUNCT.match(t[m.end():]):   # "Figure 4: ... Figure 5: ..." share one line
                captions.append((key[0], key[1], anchor))
                cap_labels.setdefault(key[0], set()).add(key[1])
                continue
            mentions.add(key)
            mention_para.setdefault(key, anchor)
            mention_text.setdefault(key, t)

    if not captions and doc.media == 0:
        return Metric("figures", None, status="not_applicable", rationale="no figures or tables")

    per_type: dict[str, list[tuple[str, int]]] = {}
    for typ, label, para in captions:
        per_type.setdefault(typ, []).append((label, para))

    findings: list = []
    for typ in sorted(per_type):
        items = per_type[typ]
        labels = [lab for lab, _ in items]
        note = _gap(labels)
        if note:
            findings.append(Finding("figures.numbering_gap", UNWEIGHED,
                                    min((para for _, para in items if para is not None), default=None),
                                    f"{typ} captions {sorted(set(labels), key=lambda l: [int(x) for x in l.replace('-', '.').split('.')])}"[:160], note))
        if len(items) >= 2:   # a single caption may be referenced as "the figure"; too weak to flag
            for label, para in sorted(items, key=lambda x: (x[0], x[1] is None, x[1] or 0)):   # table-cell captions have no paragraph
                if (typ, label) not in mentions and (typ, label) not in listed:
                    findings.append(Finding("figures.unreferenced_caption", UNWEIGHED,
                                            para, f"{typ} {label}", f"{typ} {label} not referenced in text"))

    for key in sorted(mentions):
        typ, label = key
        a, sep, b = label.partition("-")
        if sep and (typ, a) in listed and (typ, b) in listed and label not in cap_labels.get(typ, set()):
            continue   # "Tables 1-3" is a range of plain tables, not a chapter-numbered table 1-3
        if typ in cap_labels and label not in cap_labels[typ]:   # only when this type is captioned at all
            findings.append(Finding("figures.reference_without_caption", UNWEIGHED,
                                    mention_para[key], mention_text[key], f"{typ} {label} referenced, no caption"))

    look: list = []
    if doc.media > 0 and not captions:
        look.append(Finding("figures.images_without_captions", 0.0, None, "", f"{doc.media} image(s), no captions"))

    nfig, ntab = len(per_type.get("figure", [])), len(per_type.get("table", []))
    bits: list = []
    if nfig:
        bits.append(f"{nfig} figure captions")
    if ntab:
        bits.append(f"{ntab} table captions")
    if doc.media and not captions:
        bits.append(f"{doc.media} uncaptioned images")
    return Metric("figures", None, findings=findings, look=look,
                  rationale=", ".join(bits) or "no captions", status="ok")
