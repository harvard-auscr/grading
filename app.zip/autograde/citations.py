"""Metric 2: citation integrity — reference-list parsing + in-text markers, cross-checked.

Deterministic only. parse_refs and markers are pure over the Doc; run() ties them together
and emits findings under the precision guards the plan/amendments name.
"""
from __future__ import annotations

import re
import unicodedata

from autograde import headings
from autograde.model import Finding, Marker, Metric, Ref, UNWEIGHED


_MONTHS = {"January", "February", "March", "April", "May", "June", "July", "August",
           "September", "October", "November", "December", "Jan", "Feb", "Mar", "Apr",
           "Jun", "Jul", "Aug", "Sep", "Sept", "Oct", "Nov", "Dec"}
# first token of a parenthetical/narrative that is never an author surname (amendment 7)
STOP_TOKENS = _MONTHS | {"Figure", "Table", "Section", "Chapter", "Equation", "Eq", "Appendix",
                         "Model", "Grade", "Class", "Since", "From", "In", "After", "Before",
                         "During", "Act", "Law", "No", "Vol", "Ibid", "See", "Cf", "Also", "The", "Et", "Al", "And"}

_YEAR = re.compile(r"(19|20)\d{2}")
_YEARPAREN = re.compile(r"\((?:19|20)\d{2}[a-z]?(?:,\s*[A-Za-z]+(?:\s\d{1,2})?)?\)")   # also "(2016, May)"
_DOI = re.compile(r'10\.\d{4,9}/(?:[^\s\]>"()]|\([^\s()]*\))+')   # balanced parens: 10.1016/S0165-1765(97)00141-2
_DOI_WRAP = re.compile(r" ([0-9A-Za-z][^\s\]>\"()]*)")
_URL = re.compile(r'https?://[^\s)\]>"]+')
_NUM_PREFIX = re.compile(r"^\s*(?:\[(\d+)\]|(\d+)[.)])\s+")
_NAME_TOKEN = re.compile(r"[A-Z][A-Za-zÀ-ɏ'’\-]+")   # capitalized token, particles included

# entry-start signals (amendment 9)
_START_NUM = re.compile(r"^\s*(?:\[\d+\]|\d+[.)])\s")
_START_SURNAME = re.compile(r"^[A-Z][A-Za-zÀ-ɏ'’\-]+(?:,\s+(?:[A-Z]\.|[A-Z][a-z]+|&)|\s[A-Z]{1,3}[,.]\s)")   # "Wang, H." / "Wang, Hong" / "Wang H," — never "Security, 43(2)"
_START_YEAR = re.compile(r"^[^.]{0,80}?\(\d{4}[a-z]?\)")
_SPLIT_DOUBLE = re.compile(r"\.\s+(?=[A-Z][a-z]+,\s[A-Z]\.)")
_DROP_LINE = re.compile(r"^\d+[.)]?$")   # bare page number

_PAREN = re.compile(r"\(([^()]*?(?:19|20)\d{2}[a-z]?[^()]*)\)")
_PAREN_PART = re.compile(r"^\s*(.+?),\s*((?:19|20)\d{2}[a-z]?)\b")
_PAREN_PART_NC = re.compile(r"^\s*([A-Z][^,;()]{1,60}?)\s+((?:19|20)\d{2}[a-z]?)\b")
_NARR = re.compile(
    r"(?<![A-Za-z])([A-Z][A-Za-z'’\-]+)"
    r"(?:\s+et al\.?|(?:\s+(?:and|&)\s+[A-Z][A-Za-z'’\-]+))?"
    r"\s*\(((?:19|20)\d{2}[a-z]?)\)")
_BRACKET = re.compile(r"(?<![\w])\[(\d+(?:\s*[,\-–—]\s*\d+)*)\]")
_BRACKET_GLUED = re.compile(r"(?<=[A-Za-z]{3})\[(\d+(?:\s*[,\-–—]\s*\d+)*)\](?![A-Za-z])")   # "Tay[1]", "norms[2,3]"
_SUP = re.compile(r"⟦sup:(\d+)⟧")
_FN = re.compile(r"⟦fn:(\d+)⟧")
_SENT_BOUND = re.compile(r"[.!?]+(?=\s|$)|\n+")
# a period after these does not end the sentence: "et al. (2020)", "e.g. the", "Fig. 3", "J. Smith"
_ABBREV = re.compile(r"(?:\b(?:et al|e\.g|i\.e|cf|vs|viz|ca|approx|Fig|Figs|Eq|Eqs|No|Nos|Vol|pp|p|Dr|Mr|Mrs|Ms|Prof|St|Jr|Sr|Inc|Ltd|Co)"
                     r"|(?<![A-Za-z.])[A-Z])$")   # an initial ("J. Smith"), but "U.S." still closes a sentence
_PRE_CAP = re.compile(r"([A-Z][A-Za-zÀ-ɏ'’\-]*)\s+$")
_SENT_HEAD = re.compile(r"(?:^|[.!?\n]\s*)$")
_SUP_BEFORE = re.compile(r"(?:[.,;:)]|[A-Za-z]{3,})$")   # else it is a math exponent (m2, V3, 10^5)


# --- reference list -------------------------------------------------------

def _region(paras) -> tuple[int | None, int, int]:
    """(heading position, first body position, end position) of the reference list, or (None, .., ..)."""
    start = None
    for pos, p in enumerate(paras):
        t = p.text.strip()
        if not t:
            continue
        if (p.heading and headings.canon(t) == "references") or headings.inline(t, "references"):
            start = pos
            break
    if start is None:
        return None, 0, 0
    end = len(paras)
    for pos in range(start + 1, len(paras)):
        p = paras[pos]
        if p.heading and headings.canon(p.text) in ("appendix", "acknowledgments"):
            end = pos
            break
    return start, start + 1, end


def _is_start(t: str) -> bool:
    return bool(_START_NUM.match(t) or _START_SURNAME.match(t) or _START_YEAR.match(t))


def _names(author_seg: str) -> list[str]:
    # de-dup while preserving order so "De Vries" keeps both tokens once
    seen: dict[str, None] = {}
    for tok in _NAME_TOKEN.findall(author_seg):
        seen.setdefault(tok, None)
    return list(seen)


def _title(raw: str, yp: re.Match | None) -> str:
    if yp:
        tail = raw[yp.end():].lstrip(" .")
        tail = _URL.sub("", _DOI.sub("", tail)).strip()
        return tail.split(".", 1)[0].strip()[:200]
    parts = [s.strip() for s in re.split(r"(?<=[.!?])\s+", raw) if s.strip()]
    return (max(parts, key=len) if parts else "")[:200]


def _make_ref(i: int, raw: str, para: int) -> Ref:
    raw = raw.strip()
    r = Ref(i=i, raw=raw[:600], para=para)
    m = _NUM_PREFIX.match(raw)
    if m:
        r.num = int(m.group(1) or m.group(2))
        raw_body = raw[m.end():]
    else:
        raw_body = raw
    doi = _DOI.search(raw)
    if doi:
        d = doi.group(0)
        more = _DOI_WRAP.match(raw, doi.end()) if d[-1] in "-./_" else None
        if more and (d[-1] != "." or more.group(1)[0].isdigit()):   # a sentence-ending "." needs "ARXIV. 2203.1"
            # "10.1111/j.1471- 0528.2009.x": a line wrap left a space inside the DOI
            d += more.group(1)
        r.doi = d.rstrip(".,;")
    url = _URL.search(raw)
    if url:
        r.url = url.group(0).rstrip(".,;")
    y = _YEAR.search(raw)
    if y:
        r.year = int(y.group(0))
    yp = _YEARPAREN.search(raw_body)
    author_seg = raw_body[:yp.start()] if yp else raw_body.split(". ", 1)[0]
    r.names = _names(author_seg)
    r.title = _title(raw_body, yp)
    return r


def parse_refs(doc) -> list[Ref]:
    head, body_start, body_end = _region(doc.paras)
    if head is None:
        return []
    entries: list[list] = []   # [lines, para]
    for pos in range(body_start, body_end):
        p = doc.paras[pos]
        t = p.text.strip()
        if not t or _DROP_LINE.match(t) or len(t) <= 2:
            continue
        if _is_start(t) or not entries:
            entries.append([[t], p.i])
        else:
            entries[-1][0].append(t)   # joined once below: growing one string per line is quadratic on long lists
    refs: list[Ref] = []
    for parts, para in entries:
        text = re.sub(r"\s+", " ", " ".join(parts)).strip()
        pieces = _SPLIT_DOUBLE.split(text) if len(_YEARPAREN.findall(text)) >= 2 else [text]
        for piece in pieces:
            piece = piece.strip()
            if piece:
                refs.append(_make_ref(len(refs) + 1, piece, para))
    return refs


# --- in-text markers ------------------------------------------------------

def _tokens(name_part: str) -> list[str]:
    return [t for t in re.findall(r"[A-Za-zÀ-ɏ'’\-]{2,}", name_part) if t[0].isupper() and t.capitalize() not in STOP_TOKENS]


def cite_key(name_part: str) -> str:
    """First usable surname token, shared by parenthetical and narrative forms."""
    toks = _tokens(name_part)
    return toks[0] if toks else ""


def _fold(s: str) -> str:
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower().replace("-", "")


def _is_boundary(text: str, m: re.Match) -> bool:
    """A period ends the sentence unless it closes an abbreviation or an initial, or lower case follows."""
    if m.group().startswith("\n"):
        return True
    if _ABBREV.search(text[:m.start()]):
        return False
    return not text[m.end():].lstrip()[:1].islower()


def _sentence(text: str, pos: int) -> str:
    left, right = 0, len(text)
    for m in _SENT_BOUND.finditer(text):
        if not _is_boundary(text, m):
            continue
        if m.end() <= pos:
            left = m.end()
        else:
            right = m.end()
            break
    sent = re.sub(r"\s+", " ", text[left:right]).strip()
    if len(sent) > 500:   # 1% of the corpus's citing sentences; cut on a word so the judge sees whole words
        sent = sent[:500].rsplit(" ", 1)[0]
    return sent


def _expand(group: str) -> list[int]:
    out: list[int] = []
    for part in group.split(","):
        part = part.strip()
        rng = re.match(r"^(\d+)\s*[\-–—]\s*(\d+)$", part)
        if rng:
            a, b = int(rng.group(1)), int(rng.group(2))
            if a <= b <= a + 99:
                out += list(range(a, b + 1))
        elif part.isdigit():
            out.append(int(part))
    return out


def _lead_caps(before: str) -> list[str]:
    """Up to 3 capitalized words right before a narrative marker ("Tuckman Procrastination" Scale (1991)).
    A sentence-initial capital is grammar, not part of the proper noun, so it stops the walk."""
    out: list[str] = []
    while len(out) < 3:
        m = _PRE_CAP.search(before)
        if not m or _SENT_HEAD.search(before[:m.start(1)]):
            break
        out.insert(0, m.group(1))
        before = before[:m.start(1)]
    return out


def _match(name_part: str, year: int, refs: list[Ref]) -> tuple[list[int], list[int]]:
    """(entries with the same year, entries by the same author with another year).
    Any token of the citation may be the surname ("Grace Holland", "van Parijs"); the raw entry text is the
    fallback so particles, accents and corporate names never turn a real entry into a dangling citation."""
    toks = [_fold(t) for t in _tokens(name_part)]
    acros = [t for t in _tokens(name_part) if t.isupper() and len(t) >= 2]
    same, near = [], []
    for r in refs:
        names = [_fold(n) for n in r.names if n]
        raw = " " + re.sub(r"[^a-z0-9 ]", " ", _fold(r.raw)) + " "
        hit = any(t.startswith(n) or n.startswith(t) for t in toks for n in names) or any(f" {t} " in raw for t in toks)
        if not hit and acros:
            initials = "".join(n[0] for n in r.names if n).upper()
            hit = any(a in initials or a in "".join(r.names).upper() for a in acros)
        if hit:
            (same if r.year == year else near).append(r.i)
    return sorted(same), sorted(near)


def _is_numbered(refs: list[Ref]) -> bool:
    return bool(refs) and sum(1 for r in refs if r.num is not None) >= (len(refs) + 1) // 2


def _numeric_marker(n: int, para: int, sent: str, refs: list[Ref]) -> Marker:
    return Marker(para=para, text=sent, key=f"n:{n}", entries=sorted(r.i for r in refs if r.num == n))


def _scan(doc, refs: list[Ref]) -> tuple[list[Marker], bool]:
    """(markers, brackets-present-but-list-unnumbered). Reference-list paragraphs are skipped."""
    head, _, body_end = _region(doc.paras)
    numbered = _is_numbered(refs)
    ay: list[Marker] = []
    bracket_hits: list[tuple[int, str, int]] = []   # (para, sentence, number)
    sup_hits: list[tuple[int, str, int]] = []
    saw_bracket = False

    for pos, p in enumerate(doc.paras):
        if head is not None and head <= pos < body_end:
            continue
        text = p.text
        if not text.strip():
            continue
        for m in _PAREN.finditer(text):
            sent = _sentence(text, m.start())
            for part in m.group(1).split(";"):
                pm = _PAREN_PART.match(part)
                loose = pm is None   # "(Smith et al. 2014)": no comma, so it counts only when an entry matches
                pm = pm or _PAREN_PART_NC.match(part)
                if not pm:
                    continue
                name_part, ytok = pm.group(1).strip(), pm.group(2)
                surname = cite_key(name_part)
                if not surname:
                    continue
                same, near = _match(name_part, int(ytok[:4]), refs)
                if loose and not same:
                    continue
                ay.append(Marker(para=p.i, text=sent, key=f"{surname.lower()}:{ytok[:4]}", entries=same, near=near))
        for m in _NARR.finditer(text):
            surname, ytok = m.group(1), m.group(2)
            if surname.capitalize() in STOP_TOKENS:
                continue
            lead = _lead_caps(text[:m.start()])
            same, near = _match(" ".join(lead + [m.group(0)]), int(ytok[:4]), refs)
            if lead and not same and not near:
                continue   # tail of a multi-word proper noun that matches nothing: never a citation
            ay.append(Marker(para=p.i, text=_sentence(text, m.start()),
                             key=f"{surname.lower()}:{ytok[:4]}", entries=same, near=near))
        for m in _BRACKET.finditer(text):
            saw_bracket = True
            for n in _expand(m.group(1)):
                bracket_hits.append((p.i, _sentence(text, m.start()), n))
        if numbered:   # a bracket glued to a word may be code (data[2]): count it only as a number inside the list
            for m in _BRACKET_GLUED.finditer(text):
                for n in _expand(m.group(1)):
                    if n <= len(refs):
                        saw_bracket = True
                        bracket_hits.append((p.i, _sentence(text, m.start()), n))
        for m in _SUP.finditer(text):
            if _SUP_BEFORE.search(text[:m.start()]):
                sup_hits.append((p.i, _sentence(text, m.start()), int(m.group(1))))

    markers = list(ay)
    if numbered and bracket_hits:
        markers += [_numeric_marker(n, para, sent, refs) for para, sent, n in bracket_hits if n > 0]
    elif numbered and not saw_bracket and len(sup_hits) >= 3:
        markers += [_numeric_marker(n, para, sent, refs) for para, sent, n in sup_hits if n > 0]
    return markers, (saw_bracket and not numbered)


def markers(doc, refs: list[Ref]) -> list[Marker]:
    return _scan(doc, refs)[0]


# --- metric ---------------------------------------------------------------

def _complete(r: Ref) -> bool:
    core = sum((bool(r.names), r.year is not None, bool(r.title)))
    after = r.raw.split(r.title, 1)[1] if r.title and r.title in r.raw else ""
    venue = bool(r.doi or r.url) or bool(re.search(r"[A-Za-z]{3,}", after))
    return core >= 2 and venue


def _fn_numbers(doc) -> list[int]:
    out: list[int] = []
    for p in doc.paras:
        out += [int(n) for n in _FN.findall(p.text)]
    return out


def run(doc) -> tuple[Metric, list[Ref], list[Marker]]:
    refs = parse_refs(doc)
    mks, unnumbered_brackets = _scan(doc, refs)

    by_i = {r.i: r for r in refs}
    for m in mks:
        for i in m.entries:
            by_i[i].cited += 1

    numbered = _is_numbered(refs)
    findings: list[Finding] = []
    look: list[Finding] = []

    # dangling: a marker with no candidate entry, only meaningful once the list has >= 3 entries
    if len(refs) >= 3:
        seen: set[str] = set()
        for m in mks:
            if m.entries or m.key in seen:
                continue
            seen.add(m.key)
            if m.near:   # same author, other year: could be a typo or a second work — never a deduction
                look.append(Finding("citations.year_mismatch", 0.0, m.para, m.text,
                                    f"{m.key} cited; entry {m.near[0]} has another year"))
            else:
                findings.append(Finding("citations.dangling", UNWEIGHED, m.para,
                                        m.text, f"no reference entry for {m.key}"))

    # uncited entries; a numbered bibliography that is never cited at all is one fault, not one per entry
    cited_frac = (sum(1 for r in refs if r.cited) / len(refs)) if refs else 0.0
    head, _, end = _region(doc.paras)
    body = " " + re.sub(r"[^a-z0-9 ]", " ", _fold("\n".join(
        p.text for pos, p in enumerate(doc.paras) if not (head is not None and head <= pos < end)))) + " "
    if numbered and len(refs) >= 3 and cited_frac == 0:
        findings.append(Finding("citations.no_in_text_citations", UNWEIGHED, None, "",
                                f"{len(refs)} numbered entries, none cited in the text"))
    for r in refs:
        if r.cited or (numbered and cited_frac == 0):
            continue
        if not numbered and r.names and f" {_fold(r.names[0])} " in body:
            continue   # the author is named in the body; the marker form was just not one we parse
        note = f"entry {r.i} never cited"
        item = Finding("citations.uncited_entry", UNWEIGHED, r.para, r.raw, note)
        if numbered or cited_frac >= 0.70:
            findings.append(item)
        else:
            item.weight = 0.0
            look.append(item)

    # mixed styles
    numeric = sum(1 for m in mks if m.key.startswith("n:"))
    author_year = len(mks) - numeric
    if numeric >= 2 and author_year >= 2:
        findings.append(Finding("citations.mixed_styles", UNWEIGHED, None, "",
                                f"{author_year} author-year and {numeric} numeric in-text citations"))

    # duplicates by normalized title or DOI
    emitted: set[int] = set()
    seen_title: dict[str, int] = {}
    seen_doi: dict[str, int] = {}
    for r in sorted(refs, key=lambda x: x.i):
        nt = re.sub(r"[^a-z0-9]+", "", r.title.lower()) if r.title else ""
        nt = (nt + "|" + _fold(r.names[0])) if nt and r.names else nt   # same title by different authors is not a duplicate
        if nt and len(nt) >= 8:
            if nt in seen_title and r.i not in emitted:
                emitted.add(r.i)
                findings.append(Finding("citations.duplicate_entry", UNWEIGHED, r.para,
                                        r.raw, f"duplicate of entry {seen_title[nt]}"))
            seen_title.setdefault(nt, r.i)
        if r.doi:
            if r.doi in seen_doi and r.i not in emitted:
                emitted.add(r.i)
                findings.append(Finding("citations.duplicate_entry", UNWEIGHED, r.para,
                                        r.raw, f"duplicate DOI of entry {seen_doi[r.doi]}"))
            seen_doi.setdefault(r.doi, r.i)

    # incomplete entries
    for r in refs:   # look only: the completeness heuristic misreads MLA and report-style entries too often to deduct
        if not _complete(r):
            look.append(Finding("citations.incomplete_entry", 0.0, r.para, r.raw, "missing author/year/title or venue?"))

    # no reference list at all, yet the body cites
    if not refs and len(mks) >= 3:
        findings.append(Finding("citations.no_reference_list", UNWEIGHED, None, "",
                                f"{len(mks)} in-text citations but no reference list"))

    if unnumbered_brackets:
        look.append(Finding("citations.bracket_numbers_no_numbered_list", 0.0, None, "",
                            "[n] markers present but the reference list is not numbered"))

    # footnotes
    empties = sum(1 for t in doc.footnotes if not (t or "").strip())
    if doc.footnotes and empties:
        findings.append(Finding("citations.footnote_empty", UNWEIGHED, None, "",
                                f"{empties} empty footnote(s)"))
    fn = _fn_numbers(doc)
    if any(fn[k] < fn[k - 1] for k in range(1, len(fn))):
        findings.append(Finding("citations.footnote_order", UNWEIGHED, None, "",
                                f"footnote references out of order: {fn}"))

    status = "not_applicable" if (not refs and not mks) else "ok"
    bits: list[str] = []
    if refs:
        bits.append(f"{len(refs)} entries")
    if mks:
        bits.append(f"{len(mks)} in-text")
    codes = sorted({f.code.split('.', 1)[1] for f in findings})
    if codes:
        bits.append(", ".join(codes))
    rationale = "; ".join(bits) or "no citations to check"
    return Metric("citations", None, findings=findings, look=look, rationale=rationale, status=status), refs, mks
