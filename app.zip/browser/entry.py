"""The in-browser grader's Python side.

The page's worker (browser/site/worker.js) unpacks app.zip into /app, writes the dropped files into /work/in and calls
run(). The browser is reached only through the two callables the worker passes in: xhr (one synchronous request) and
post (a progress message to the page). Under CPython the tests pass fakes for both.

/work/in holds: the papers (one or more .zip files from Drive's folder download, and/or .docx files) under papers/,
the mastersheet as sheet.csv (optional) and the rubric as rubric.toml. run() deletes it when the round ends.
"""
from __future__ import annotations

import csv
import gc
import json
import os
import re
import shutil
import sys
import urllib.parse
import zipfile
from pathlib import Path

import grade
from autograde import llm, net, redact, rubric
from autograde import sheet as sheets_mod
from tools import compile_html, ingest_papers

LOOKUP_HOSTS = ("api.openalex.org", "api.crossref.org", "doi.org")   # the page's CSP lists the same hosts
LLM_HOSTS = {"deepseek": "api.deepseek.com", "openai": "api.openai.com"}
PROVIDER_NAMES = {"deepseek": "DeepSeek", "openai": "OpenAI", "anthropic": "Claude (Anthropic)"}
_A = {"deepseek": "a DeepSeek", "openai": "an OpenAI", "anthropic": "a Claude (Anthropic)"}
KEY_VARS = ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
            "LLM_PROVIDER", "LLM_MODEL", "LLM_BASE_URL", "OPENALEX_API_KEY")
# seconds for a whole AI reply: the browser's timeout covers the request, not each read, and DeepSeek may hold a
# request for up to 30 minutes under load before it answers
LLM_TIMEOUT = 1900
_DOI, _HANDLES = "https://doi.org/", "https://doi.org/api/handles/"
_PROGRAM = re.compile(r"[a-z][a-z0-9]{0,15}")
RND = 1   # the page asks for no round: the papers are one round, and their IDs leave it out (ysa-01)
_KEY = re.compile(r"[\x21-\x7e]{8,512}")


class Stop(Exception):
    """A plain sentence for the person grading; never a path, a name or the key."""


def _send(xhr, method: str, url: str, headers, data, timeout: float) -> tuple[int, str, bytes]:
    try:
        res = xhr(method, url, json.dumps(headers or {}), None if data is None else data.decode("utf-8"),
                  int(timeout * 1000))
        status, ctype, body = int(res[0]), str(res[1] or ""), res[2]
    except Exception as e:   # the browser's NetworkError, a timeout, a CORS refusal
        raise net.NetError(type(e).__name__) from None
    if status == 0:          # what a CORS refusal or a dropped connection looks like from a page
        raise net.NetError("no response")
    return status, ctype, body.to_bytes() if hasattr(body, "to_bytes") else bytes(body)


def make_transport(xhr, hosts):
    """net.TRANSPORT over the worker's synchronous XHR, for https on the listed hosts only."""
    hosts = frozenset(hosts)
    ai_hosts = frozenset(LLM_HOSTS.values())

    def transport(method, url, *, follow=3, headers=None, data=None, timeout=net.TIMEOUT):
        if not url.isascii():   # the desktop's urllib refuses such a URL too (ValueError), so the entry stays unchecked
            raise ValueError("a URL with characters outside ASCII")
        u = urllib.parse.urlsplit(url)
        if u.scheme != "https" or u.hostname not in hosts or u.port not in (None, 443) or u.username or u.password:
            raise net.NetError(f"refused {url[:80]}")
        if method == "HEAD" and follow == 0 and url.startswith(_DOI):
            # status_only: "is this DOI registered?" A page cannot see a redirect's status, so ask the DOI handle
            # server, which answers 200 (registered) or 404 itself. Like the desktop, it never touches the publisher.
            status, _ctype, _body = _send(xhr, "GET", _HANDLES + url[len(_DOI):], None, None, timeout)
            return (302 if status == 200 else status), "", b""
        return _send(xhr, method, url, headers, data, LLM_TIMEOUT if u.hostname in ai_hosts else timeout)
    return transport


def _papers(inbox: Path) -> list[Path]:
    found = sorted(p for p in (inbox / "papers").iterdir() if p.is_file()) if (inbox / "papers").is_dir() else []
    papers = [p for p in found if p.suffix.lower() == ".zip" or p.suffix.lower() in ingest_papers.PREFER]
    if not papers:
        raise Stop("Add the papers: the .zip Google Drive makes when you download the folder, or the .docx files.")
    return papers


def _ingest(program: str, papers: list[Path], sheet: Path | None, data: Path) -> dict:
    try:
        return ingest_papers.ingest_sources(program, "", RND, papers, sheet, data, round_in_ids=False)
    except (zipfile.BadZipFile, NotImplementedError):   # a damaged directory can claim an unknown zip version
        raise Stop("One of the papers files is not a .zip that can be opened.") from None
    except csv.Error:
        raise Stop("The mastersheet could not be read as a .csv file (a cell may be far too long).") from None
    except UnicodeDecodeError:
        raise Stop("The mastersheet is not a UTF-8 .csv file. In Google Sheets: File, Download, "
                   "Comma-separated values.") from None
    except StopIteration:
        raise Stop("The mastersheet has no header row with a \"Paper Title\" column.") from None
    except SystemExit:
        raise Stop("The mastersheet has no \"File Name\" or \"Paper Folder\" column.") from None
    except ValueError as e:   # SheetError and the sheet's other plain sentences
        raise Stop(str(e)) from None


def _program(o: dict) -> str:
    """What the papers are numbered under (ysa -> ysa-01): the program typed on the page, else the letters and digits
    of the rubric's file name ("ysa (1).toml" -> ysa), else "paper". app.js shows the same as the field's placeholder."""
    program = str(o.get("program") or "").strip().lower()
    if program and not _PROGRAM.fullmatch(program):
        raise Stop("The program name must be letters and digits, starting with a letter (for example ysa).")
    stem = re.sub(r"\.toml$", "", str(o.get("rubric_name") or "").strip().lower())
    stem = re.sub(r"[^a-z0-9]", "", re.sub(r"\s*\(\d+\)$", "", stem))[:16]
    return program or (stem if _PROGRAM.fullmatch(stem) else "paper")


def _provider(o: dict, key: str) -> str:
    provider = str(o.get("provider") or "deepseek")
    if provider not in LLM_HOSTS:
        raise Stop("Pick DeepSeek or OpenAI as the AI service.")
    if not _KEY.fullmatch(key):
        raise Stop("That key has spaces or characters a key never has. Paste it again.")
    looks = llm.key_family(key)
    if looks == "anthropic":
        raise Stop("Claude (Anthropic) keys do not work in the browser grader yet. Use a DeepSeek or OpenAI key, "
                   "or leave the key empty to run the checks that need no AI.")
    if looks and looks != provider:   # never send one company's key to another
        raise Stop(f"That looks like {_A[looks]} key, but {PROVIDER_NAMES[provider]} is picked. "
                   f"Pick {PROVIDER_NAMES[looks]}, or paste {_A[provider]} key.")
    return provider


def _named(sheet: Path, rnd: int, data: Path) -> int:
    """Check, before any AI call, that the mastersheet can mask the students' names; returns how many papers have
    no named row (they are graded without the AI checks)."""
    rows = sheets_mod.load(sheet)
    if not any(redact.names_known(r) for r in rows.values()):
        raise Stop("The mastersheet has no student names (an \"EN Name\" or \"CN Name\" column), so nothing could "
                   "be masked before the AI checks. Use the round's own tab, or leave the key empty.")
    papers = sheets_mod.manifest(data / "manifest.csv")
    unnamed = sum(1 for m in papers if not redact.names_known(sheets_mod.row_for(m, {rnd: rows})))
    if papers and unnamed == len(papers):
        raise Stop("No paper matched a row with a name on this mastersheet, so nothing could be masked before the AI "
                   "checks. Is it the round's own tab? Or leave the key empty.")
    return unnamed


def run(opts_json: str, xhr, post, work: str = "/work") -> str:
    """Grade the round in <work>/in. opts: program (optional), key (optional), provider (deepseek|openai), offline
    (bool), rubric_name (the picked file's name: for messages, and the program when none is typed). Returns JSON for the page: {"ok": true, "slug", "ingest", "summary", "llm", "llm_status",
    "no_ai"} or {"ok": false, "error": <sentence>}. The outputs stay in <work>/out/<slug>/ and <work>/result.zip."""
    w = Path(work)
    inbox, data = w / "in", w / "data"
    o = json.loads(opts_json)
    holder: dict = {}
    real_make = llm.make_client
    cwd = os.getcwd()
    try:
        program = _program(o)
        key = str(o.get("key") or "").strip()
        provider = _provider(o, key) if key else None
        rub = inbox / "rubric.toml"
        if not rub.is_file():
            raise Stop("Add the rubric: the program's .toml file from the grader's rubric folder.")
        try:   # the whole rubric is checked before any paper is read
            rubric.load(rub)
        except rubric.RubricError as e:   # named as the grader picked it, not as the worker saved it
            picked = re.sub(r"[^\w .-]", "", str(o.get("rubric_name") or ""))[:80] or rub.name
            raise Stop(f"The rubric has a mistake: {str(e).replace(rub.name, picked)}") from None
        sheet = inbox / "sheet.csv" if (inbox / "sheet.csv").is_file() else None
        if key and sheet is None:   # the sheet's names are what redaction masks; without it nothing goes to an AI
            raise Stop("With a key, add the mastersheet too: its names are what the grader masks before any text "
                       "goes to the AI service.")
        papers = _papers(inbox)

        slug = program
        out = w / "out" / slug            # apart from in/ and data/, whatever the program is called
        for d in (data, out):
            shutil.rmtree(d, ignore_errors=True)
        (w / "result.zip").unlink(missing_ok=True)
        os.chdir(w)                       # the lookup cache (.cache/lookups.sqlite) lives here for the session
        counts = _ingest(program, papers, sheet, data)
        post("ingest", json.dumps(counts))
        if not counts["stored"] + counts["present"]:
            raise Stop("None of the files added is a paper the grader can read (.docx).")
        no_ai = _named(sheet, RND, data) if key else 0

        for k in KEY_VARS:                # only what this round was given
            os.environ.pop(k, None)
        hosts = set(LOOKUP_HOSTS)
        if key:
            os.environ[llm.PROVIDERS[provider][0]], os.environ["LLM_PROVIDER"] = key, provider
            hosts.add(LLM_HOSTS[provider])

        def capture():
            holder["client"] = real_make()
            return holder["client"]
        llm.make_client = capture
        net.TRANSPORT = make_transport(xhr, hosts)
        grade.AI_NEEDS_NAMES = True
        grade.ON_PAPER = lambda pid, status, done, total: post(
            "paper", json.dumps({"paper": pid, "status": status, "done": done, "total": total}))
        argv = ["--rubric", str(rub), "--papers", str(data), "--out", str(out)]
        if sheet:
            argv += ["--sheet", f"{RND}={sheet}"]
        if not key:
            argv.append("--no-llm")
        if o.get("offline"):
            argv.append("--offline")
        grade.main(argv)                  # 1 when some papers were unparsed/failed; that is not an error
        post("report", "{}")
        (out / "report.html").write_text(compile_html.build(out), encoding="utf-8")
        with zipfile.ZipFile(w / "result.zip", "w", zipfile.ZIP_DEFLATED) as z:
            for p in sorted(out.iterdir()):
                z.write(p, f"{slug}/{p.name}")
        rows = (out / "summary.csv").read_text(encoding="utf-8").splitlines()[1:]
        summary = {"papers": len(rows), "ok": sum(1 for r in rows if r.rsplit(",", 1)[-1] == "ok")}
        c = holder.get("client")
        return json.dumps({"ok": True, "slug": slug, "ingest": counts, "summary": summary, "no_ai": no_ai,
                           "llm": (out / "usage.csv").exists(),
                           "llm_status": getattr(c, "status", None) if c is not None else None})
    except Stop as e:
        return json.dumps({"ok": False, "error": str(e)})
    finally:
        os.chdir(cwd)
        llm.make_client = real_make
        net.TRANSPORT = None
        grade.ON_PAPER = None
        grade.AI_NEEDS_NAMES = False
        for k in KEY_VARS:
            os.environ.pop(k, None)
        holder.clear()
        shutil.rmtree(data, ignore_errors=True)    # the ingested copies of the papers; the outputs stay
        shutil.rmtree(inbox, ignore_errors=True)   # and what was dropped, however the round ended
        o.clear()                                  # the key, from this frame's locals
        key = opts_json = None
        sys.last_exc = sys.last_value = sys.last_traceback = sys.last_type = None
        gc.collect()                               # the parsed papers, held in cycles until a collection
